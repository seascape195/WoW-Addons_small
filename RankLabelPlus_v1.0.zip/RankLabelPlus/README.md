# Rank Label Plus

Add spell rank labels to your casting icons. It is non-destructive to any other graphics.

For WoW Classic Forever (interface 16001). Version 0.1, not yet tested in-game.

## Install
1. Copy this folder into `World of Warcraft/_classic_/Interface/AddOns/` (or your Forever client's `Interface/AddOns` folder).
2. Name the folder `RankLabelPlus` so it matches `RankLabelPlus.toc`. The game won't load it otherwise.
3. At character select, open AddOns and make sure Rank Label Plus is enabled.

## Use
- Type `/irank` to open settings (the settings panel is still a placeholder in v0.1).
- Rank labels appear in the lower-left corner of each icon, font size 12 by default.
- Mana cost is off by default. When turned on, it shows in the upper-left corner.
- Duration shows centered above the icon.
