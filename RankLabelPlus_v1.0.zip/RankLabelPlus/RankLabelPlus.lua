--[[
  Rank Label Plus v0.1 (scaffolding only)
  Author: Seascape
  Spec: /workspace/spell-rank-addon-spec/SPEC_spell_rank_icons_v1.md

  Display only: this add-on never casts, swaps, picks up, or places anything
  on the action bars (Spec 1 and 6). It only adds text labels on top of buttons.
  Forever (interface 16001) ships first; TBC Anniversary differences go in the
  VERSION section below (Spec 6, Game versions).
]]

local ADDON_NAME = ...
RankLabelPlus = RankLabelPlus or {}
local RLP = RankLabelPlus

---------------------------------------------------------------------------
-- VERSION (Spec 6: Game versions)
-- Keep every per-version difference (Forever vs TBC Anniversary) in this
-- one small section so the rest of the code is shared.
---------------------------------------------------------------------------
local INTERFACE = select(4, GetBuildInfo())
RLP.isForever = (INTERFACE >= 16000 and INTERFACE < 20000)
RLP.isTBCAnniversary = false -- TODO: set once the TBC Anniversary interface number is confirmed

---------------------------------------------------------------------------
-- DEFAULT SETTINGS (Spec 2, 3, 4, 5)
---------------------------------------------------------------------------
RLP.defaults = {
  rank = {
    position    = "LOWERLEFT", -- "LOWERLEFT" (default) or "LEFTCENTER"; never middle or upper-right
    offsetX     = 9,           -- Left/Right nudge, default X 9 (the cap)
    offsetY     = 1,           -- Up/Down nudge, default Y 1
    fontScale   = 13,          -- rank label (and duration) size, default 13; slider range 2.0 to 36
    manaFontScale = 11,        -- mana cost text size only, default 11; slider range 2.0 to 36
    thickness   = "MAX",       -- "NORMAL" (OUTLINE) or "MAX" (THICKOUTLINE); default Max
    color       = { r = 0xFD / 255, g = 0x9A / 255, b = 0x00 / 255 }, -- RGB numbers; default orange #FD9A00
    manaCostColor = { r = 0x66 / 255, g = 0xB3 / 255, b = 0xFF / 255 }, -- mana cost color; default baby blue #66B3FF
  },
  -- Drop shadows, kept separately for rank labels (also used by duration text)
  -- and for mana cost text. Colors: "BLACK", "WHITE", "LIGHT_GRAY" (Medium gray was removed).
  rankShadow = {
    enabled = true,
    color   = "BLACK",
  },
  manaShadow = {
    enabled = true,
    color   = "BLACK",
  },
  mana = {
    enabled = true,            -- "Show mana cost" checkbox, on by default (upper-left)
  },
  -- Mana cost text position: "TOPLEFT" (default, the original spot) or
  -- "TOPCENTER", plus a nudge in pixels; same 9-pixel cap as the rank label.
  manaPos = {
    position = "TOPLEFT",
    offsetX  = 1,              -- default nudge X 1, Y -2 (set Nov 10, 2026)
    offsetY  = -2,
  },
  duration = {
    enabled = true,            -- static tooltip duration, centered above icon
  },
}

-- Named palettes used to migrate old saved color names to RGB numbers.
RLP.rankColors = {
  RED    = { 1, 0, 0 },
  YELLOW = { 1, 1, 0 },
  BLUE   = { 0, 0.4, 1 },
  GREEN  = { 0, 1, 0 },
}
RLP.shadowColors = {
  BLACK       = { 0, 0, 0 },
  WHITE       = { 1, 1, 1 },
  LIGHT_GRAY  = { 0.7, 0.7, 0.7 },
}
RLP.thicknessFlags = {
  NORMAL = "OUTLINE",     -- thin outline
  MAX    = "THICKOUTLINE",
}
RLP.FONT_SCALE_MIN, RLP.FONT_SCALE_MAX = 2.0, 36
RLP.OFFSET_MIN, RLP.OFFSET_MAX = -9, 9

-- Fills missing keys in the saved settings from the defaults.
local function ApplyDefaults(db, defaults)
  for k, v in pairs(defaults) do
    if type(v) == "table" then
      if type(db[k]) ~= "table" then db[k] = {} end
      ApplyDefaults(db[k], v)
    elseif db[k] == nil then
      db[k] = v
    end
  end
end

---------------------------------------------------------------------------
-- BUTTON DISCOVERY (Spec 6: Compatibility)
-- Find Blizzard default action buttons (all eight bar sets) and Bartender 4
-- buttons. When Bartender 4 is loaded it hides Blizzard's buttons and draws
-- its own in the same spot, so only Bartender's buttons get labels then.
---------------------------------------------------------------------------
RLP.labels = {} -- [button] = { rank = FontString, mana = FontString, duration = FontString }

local BLIZZARD_BAR_PREFIXES = {
  "ActionButton",
  "MultiBarBottomLeftButton",
  "MultiBarBottomRightButton",
  "MultiBarRightButton",
  "MultiBarLeftButton",
  "MultiBar5Button", -- may not exist on every client; skipped if missing
  "MultiBar6Button",
  "MultiBar7Button",
}

function RLP:GetBlizzardButtons()
  local buttons = {}
  for _, prefix in ipairs(BLIZZARD_BAR_PREFIXES) do
    for i = 1, 12 do
      local button = _G[prefix .. i]
      if button then buttons[#buttons + 1] = button end
    end
  end
  return buttons
end

-- Bartender 4 names its buttons BT4Button1 to BT4Button180 (10 bars x 12,
-- plus extra state slots). Only looked up when Bartender 4 is loaded.
local BT4_MAX_BUTTONS = 180

function RLP:IsBartenderLoaded()
  return (C_AddOns and C_AddOns.IsAddOnLoaded and C_AddOns.IsAddOnLoaded("Bartender4"))
    or (IsAddOnLoaded and IsAddOnLoaded("Bartender4")) or false
end

function RLP:GetBartenderButtons()
  local buttons = {}
  if not self:IsBartenderLoaded() then return buttons end
  for i = 1, BT4_MAX_BUTTONS do
    local button = _G["BT4Button" .. i]
    if button then buttons[#buttons + 1] = button end
  end
  return buttons
end

-- The buttons that are actually on screen: Bartender 4's when it is loaded
-- and has buttons, otherwise Blizzard's eight bar sets.
function RLP:GetActiveButtons()
  local bartender = self:GetBartenderButtons()
  if #bartender > 0 then return bartender, true end
  return self:GetBlizzardButtons(), false
end

-- Returns the action slot a button currently shows (Blizzard or Bartender 4).
function RLP:GetButtonSlot(button)
  -- Bartender 4 buttons (LibActionButton) report their action through GetAction.
  if button.GetAction then
    local kind, action = button:GetAction()
    if kind == "action" and type(action) == "number" then return action end
  end
  if type(button.action) == "number" and button.action > 0 then return button.action end
  if button.GetAttribute then
    local action = button:GetAttribute("action")
    if type(action) == "number" and action > 0 then return action end
  end
  return nil
end

-- Returns the spell ID (or nil) and the slot. The slot is always returned
-- for a filled button, because rank reading works from the slot alone; a
-- missing spell ID must never stop a rank label.
function RLP:GetButtonSpell(button)
  local slot = self:GetButtonSlot(button)
  if not slot or not HasAction(slot) then return nil, nil end
  local actionType, id = GetActionInfo(slot)
  if actionType == "spell" and id then return id, slot end
  return nil, slot
end

---------------------------------------------------------------------------
-- SPELL DATA HELPERS (Spec 6: Data source)
-- Game-provided data only. No rank tables, no network.
---------------------------------------------------------------------------
function RLP:GetManaCost(spellID)
  local costs = (GetSpellPowerCost and GetSpellPowerCost(spellID))
    or (C_Spell and C_Spell.GetSpellPowerCost and C_Spell.GetSpellPowerCost(spellID))
  if type(costs) ~= "table" then return nil end
  local manaType = (Enum and Enum.PowerType and Enum.PowerType.Mana) or 0
  for _, cost in ipairs(costs) do
    if (cost.type == manaType or cost.name == "MANA") and (cost.cost or 0) > 0 then
      return cost.cost
    end
  end
  return nil
end

-- Hidden tooltip used only to read the spell's static description text.
local scanTip
local function GetScanTooltip()
  if not scanTip then
    scanTip = CreateFrame("GameTooltip", "RankLabelPlusScanTooltip", nil, "GameTooltipTemplate")
    scanTip:SetOwner(WorldFrame, "ANCHOR_NONE")
  end
  return scanTip
end

-- Reads the rank from the tooltip, because GetSpellSubtext returns blank
-- text on Classic Forever. Looks for "Rank N" on every left and right line.
-- Order of sources:
--   1. C_TooltipInfo.GetAction(slot), the client's tooltip data (no frame needed)
--   2. Hidden tooltip SetAction(slot), exactly what you see when hovering the button
--   3. Hidden tooltip SetSpellByID(spellID) as a last resort
-- Only found ranks are cached. A "no rank" result is never cached, because at
-- login the tooltip can load before its rank line does.
RLP.rankCache = {}

local function MatchRank(text)
  local n = type(text) == "string" and text:match("Rank (%d+)")
  return n and tonumber(n) or nil
end

local function RankFromTooltipInfo(slot)
  if not (slot and C_TooltipInfo and C_TooltipInfo.GetAction) then return nil end
  local ok, data = pcall(C_TooltipInfo.GetAction, slot)
  if not ok or type(data) ~= "table" or type(data.lines) ~= "table" then return nil end
  for _, line in ipairs(data.lines) do
    local n = MatchRank(line.leftText) or MatchRank(line.rightText)
    if n then return n end
  end
  return nil
end

local function RankFromScanTooltip(slot, spellID)
  local tip = GetScanTooltip()
  tip:SetOwner(WorldFrame, "ANCHOR_NONE")
  tip:ClearLines()
  if slot then tip:SetAction(slot) else tip:SetSpellByID(spellID) end
  for i = 1, tip:NumLines() do
    local left = _G["RankLabelPlusScanTooltipTextLeft" .. i]
    local right = _G["RankLabelPlusScanTooltipTextRight" .. i]
    local n = (left and MatchRank(left:GetText())) or (right and MatchRank(right:GetText()))
    if n then return n end
  end
  return nil
end

function RLP:GetRankNumber(spellID, slot)
  if spellID and self.rankCache[spellID] then return self.rankCache[spellID] end
  local n = RankFromTooltipInfo(slot)
    or (slot and RankFromScanTooltip(slot, spellID))
    or (spellID and RankFromScanTooltip(nil, spellID))
  if n and spellID then self.rankCache[spellID] = n end
  return n
end

-- In-game check. Every line is printed to chat AND saved, so nothing is lost
-- when the chat window runs out of room.
--   /irank debug          all buttons across the eight Blizzard bar sets
--   /irank debug 1        one button by its number in that list (1-12 are
--                         ActionButton1-12, 13-24 the next bar set, and so on)
--   /irank debug ActionButton1   one button by its exact name
-- The saved copy is RankLabelPlusDB.debugLog, written to disk on /reload or
-- logout in WTF\Account\<account>\SavedVariables\RankLabelPlus.lua.
-- Each /irank debug run replaces the previous saved copy.
function RLP:Debug(filter)
  local blizzard = self:GetBlizzardButtons()
  local bartender = self:GetBartenderButtons()
  local active, usingBartender = self:GetActiveButtons()
  local log = {}
  if self.db then self.db.debugLog = log end
  local function out(line)
    print(line)
    log[#log + 1] = (line:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
  end

  local targets = active
  filter = filter and filter:match("^%s*(.-)%s*$") or ""
  if filter ~= "" then
    local index = tonumber(filter)
    local pick = index and active[index] or _G[filter]
    if not pick then
      out("|cffffd100Rank Label Plus debug|r  No button found for \"" .. filter .. "\" (1 to " .. #active .. " or a button name).")
      return
    end
    targets = { pick }
  end

  out("|cffffd100Rank Label Plus debug|r  " .. date("%Y-%m-%d %H:%M:%S")
    .. "  Blizzard buttons found: " .. #blizzard .. "  Bartender4 buttons found: " .. #bartender
    .. "  labeling: " .. (usingBartender and "Bartender4" or "Blizzard") .. "  showing: " .. #targets)
  local function report(button)
    local slot = self:GetButtonSlot(button)
    local spellID = self:GetButtonSpell(button)
    local labels = self.labels[button]
    local actionType = slot and HasAction(slot) and GetActionInfo(slot)
    out(string.format("%s type=%s slot=%s spell=%s info=%s action=%s byID=%s label=%s",
      button:GetName() or "?", tostring(actionType), tostring(slot), tostring(spellID),
      tostring(RankFromTooltipInfo(slot)),
      tostring(slot and RankFromScanTooltip(slot, spellID)),
      tostring(spellID and RankFromScanTooltip(nil, spellID)),
      tostring(labels and labels.rank:IsShown() and labels.rank:GetText())))
    if labels and labels.rank:IsShown() then
      local fs = labels.rank
      local font, size, flags = fs:GetFont()
      local point, rel, relPoint, px, py = fs:GetPoint(1)
      out(string.format("   styleFontOK=%s diagFontOK=%s font=%s size=%s flags=%s visible=%s width=%s alpha=%s point=%s/%s %s,%s parent=%s",
        tostring(fs.rlpFontOK), tostring(fs.rlpDiagFontOK), tostring(font), tostring(size),
        tostring(flags), tostring(fs:IsVisible()), tostring(fs:GetStringWidth()),
        tostring(fs:GetAlpha()), tostring(point), tostring(relPoint), tostring(px), tostring(py),
        tostring(fs:GetParent() and fs:GetParent():GetName())))
      local holder = labels.holder
      local bar = button:GetParent()
      out(string.format("   holderShown=%s holderVisible=%s buttonShown=%s buttonVisible=%s bar=%s barShown=%s barVisible=%s",
        tostring(holder and holder:IsShown()), tostring(holder and holder:IsVisible()),
        tostring(button:IsShown()), tostring(button:IsVisible()),
        tostring(bar and bar:GetName()), tostring(bar and bar:IsShown()), tostring(bar and bar:IsVisible())))
    end
  end
  for _, button in ipairs(targets) do report(button) end
  out("Saved " .. #log + 1 .. " lines to RankLabelPlusDB.debugLog. /reload to write it to disk.")
end

-- Finds how long the rank's effect lasts from its tooltip description,
-- e.g. "... for 30 sec." or "... over 2 min." Returns short text like "30s"
-- or "2m". Cast time and cooldown lines are skipped. English client text only.
function RLP:GetStaticDuration(spellID)
  local tip = GetScanTooltip()
  tip:ClearLines()
  tip:SetOwner(WorldFrame, "ANCHOR_NONE")
  tip:SetSpellByID(spellID)
  for i = tip:NumLines(), 2, -1 do -- description is near the bottom
    local line = _G["RankLabelPlusScanTooltipTextLeft" .. i]
    local text = line and line:GetText()
    if text and not text:find("cast") and not text:find("cooldown") then
      local amount, unit = text:match("[Ff]or (%d+%.?%d*) (%a+)")
      if not amount then amount, unit = text:match("[Oo]ver (%d+%.?%d*) (%a+)") end
      if not amount then amount, unit = text:match("[Ll]asts (%d+%.?%d*) (%a+)") end
      if amount and unit then
        unit = unit:lower()
        if unit:find("^sec") then return amount .. "s" end
        if unit:find("^min") then return amount .. "m" end
        if unit:find("^hour") or unit:find("^hr") then return amount .. "h" end
      end
    end
  end
  return nil
end

---------------------------------------------------------------------------
-- LABEL CREATION (Spec 2, 3, 4, 6: Combat safety)
-- Adds FontStrings on top of a button. Never modifies, hooks the secure
-- click behavior of, or reparents a button. Only runs out of combat.
---------------------------------------------------------------------------
local FONT_PATH = (GameFontNormal and GameFontNormal:GetFont()) or STANDARD_TEXT_FONT

-- Built-in game font the labels start from, the same way Blizzard's hotkey
-- text is made from a font object instead of a bare font file path.
local BASE_FONT_NAME = (NumberFontNormal and "NumberFontNormal") or "GameFontNormal"
local BASE_FONT = _G[BASE_FONT_NAME]

-- Sets the font and checks that it worked. If the call fails, falls back to
-- the built-in font so a label is never left blank. Returns true if the
-- requested font was applied.
local function SafeSetFont(fs, size, flags)
  local ok = FONT_PATH and fs:SetFont(FONT_PATH, size, flags)
  if not ok then
    if BASE_FONT then fs:SetFontObject(BASE_FONT) end
    local basePath = BASE_FONT and BASE_FONT:GetFont()
    if basePath then fs:SetFont(basePath, size, flags) end
  end
  return ok and true or false
end
RLP.SafeSetFont = SafeSetFont

-- The rank label lives on its own tiny see-through frame parented to
-- UIParent, sitting over the button's lower-left corner and layered above the
-- button and everything attached to it. The frame takes no mouse input, so
-- clicks still reach the button. It hides and shows along with its button.
local function NewHolder(button)
  local name = button:GetName()
  local holder = CreateFrame("Frame", name and ("RankLabelPlusHolder_" .. name) or nil, UIParent)
  holder:SetSize(1, 1)
  holder:SetPoint("BOTTOMLEFT", button, "BOTTOMLEFT", 0, 0)
  holder:SetFrameStrata(button:GetFrameStrata())
  holder:SetFrameLevel(button:GetFrameLevel() + 20)
  holder:EnableMouse(false)
  button:HookScript("OnHide", function() holder:Hide() end)
  button:HookScript("OnShow", function() holder:Show() end)
  return holder -- always starts shown; RefreshButton keeps it matched to the button
end

local function NewFontString(button, parent)
  local fs = (parent or button):CreateFontString(nil, "OVERLAY", BASE_FONT_NAME)
  fs:SetDrawLayer("OVERLAY", 7) -- highest level of the top layer, above Blizzard's own button art
  SafeSetFont(fs, 12, "OUTLINE")
  fs:Hide()
  return fs
end

-- Labels are created lazily: a button gets a rank FontString only when it
-- first shows a ranked spell. Mana and duration FontStrings are made at the
-- same time so all three share one table.
---------------------------------------------------------------------------
-- TRIAL: soft baby blue glow behind the rank label (added Nov 10, 2026)
-- A faint halo in the mana cost blue (66B3FF), drawn just under the rank
-- text inside the same holder frame. It doesn't touch the outline or the
-- 3-pixel shadow. To turn it off, set RLP.RANK_GLOW = false. To roll it back
-- completely, delete this block and the one AttachRankGlow call in
-- CreateLabels (or restore /tmp/gb_rlp_backup_pre_blueglow.lua).
---------------------------------------------------------------------------
RLP.RANK_GLOW = true
RLP.RANK_GLOW_COLOR = { 0x66 / 255, 0xB3 / 255, 1 }
-- Glow history: v1.3/v1.4 used solid rectangles (showed as a pale box);
-- v1.5 used eight blue copies of the text (showed as extra text layers under
-- the rank color). Since v1.6 it is one soft round highlight texture that has
-- shipped since the original game (the minimap zoom button highlight), tinted
-- 66B3FF and drawn additively behind the text. It has no letters, so it can't
-- look like extra text, and its edges fade out, so it can't look like a box.
-- It never touches the rank label's own color, outline, or shadow.
RLP.RANK_GLOW_TEXTURE = "Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight"
RLP.RANK_GLOW_PAD_X  = 7     -- how far the aura reaches past the text, left and right
RLP.RANK_GLOW_PAD_Y  = 6     -- and above and below
RLP.RANK_GLOW_ALPHA  = 0.55  -- lower to soften, raise to brighten
RLP.RANK_GLOW_BLEND  = "ADD"

function RLP:AttachRankGlow(labels)
  if not self.RANK_GLOW or labels.glow then return end
  local fs, holder = labels.rank, labels.holder
  local c = self.RANK_GLOW_COLOR
  local t = holder:CreateTexture(nil, "OVERLAY", nil, 6) -- one level under the text (7)
  t:SetTexture(self.RANK_GLOW_TEXTURE)
  t:SetVertexColor(c[1], c[2], c[3], 1)
  t:SetAlpha(self.RANK_GLOW_ALPHA)
  if t.SetBlendMode then t:SetBlendMode(self.RANK_GLOW_BLEND) end
  t:SetPoint("TOPLEFT", fs, "TOPLEFT", -self.RANK_GLOW_PAD_X, self.RANK_GLOW_PAD_Y)
  t:SetPoint("BOTTOMRIGHT", fs, "BOTTOMRIGHT", self.RANK_GLOW_PAD_X, -self.RANK_GLOW_PAD_Y)
  t:Hide()
  labels.glow = { t }
  -- The glow follows the rank text: shown when it's shown, hidden when it's hidden.
  hooksecurefunc(fs, "Show", function()
    if RLP.RANK_GLOW and (fs:GetText() or "") ~= "" then t:Show() else t:Hide() end
  end)
  hooksecurefunc(fs, "Hide", function() t:Hide() end)
end

-- /irank glow (or /ir glow): prints whether the trial glow is on, how many rank
-- labels carry it, and what the first shown one really has.
function RLP:PrintGlowDebug()
  local p = "|cffffd100RLP glow|r "
  print(p .. "RANK_GLOW=" .. tostring(self.RANK_GLOW) .. " blend=" .. tostring(self.RANK_GLOW_BLEND))
  local total, withGlow, shown, reported = 0, 0, 0, false
  for button, labels in pairs(self.labels or {}) do
    total = total + 1
    if labels.glow then
      withGlow = withGlow + 1
      if labels.rank:IsVisible() then
        shown = shown + 1
        if not reported then
          reported = true
          local t = labels.glow[1]
          local w, h = t:GetSize()
          local a = self.RANK_GLOW_ALPHA -- configured alpha per copy
          print(p .. string.format("first shown on %s: text=%s layer1 shown=%s visible=%s size=%.0fx%.0f alpha=%s holderVisible=%s",
            tostring(button.GetName and button:GetName() or "?"), tostring(labels.rank:GetText()),
            tostring(t:IsShown()), tostring(t:IsVisible()), w or 0, h or 0, tostring(a),
            tostring(labels.holder and labels.holder:IsVisible())))
        end
      end
    end
  end
  print(p .. string.format("labels=%d withGlow=%d shownRank=%d", total, withGlow, shown))
end
-- END TRIAL glow block -------------------------------------------------------

function RLP:CreateLabels(button)
  if InCombatLockdown() then
    self.pendingRefresh = true
    return nil
  end
  local labels = self.labels[button]
  if labels then return labels end
  labels = {
    mana = NewFontString(button),
    duration = NewFontString(button),
  }
  labels.holder = NewHolder(button)
  labels.rank = NewFontString(button, labels.holder)
  RLP:AttachRankGlow(labels) -- TRIAL baby blue glow; no-op when RANK_GLOW is false
  self.labels[button] = labels
  return labels
end

function RLP:CreateAllLabels()
  self:RefreshAll()
end

---------------------------------------------------------------------------
-- STYLE (Spec 2)
---------------------------------------------------------------------------
local function ClampScale(v)
  v = tonumber(v) or RLP.FONT_SCALE_MIN
  if v < RLP.FONT_SCALE_MIN then v = RLP.FONT_SCALE_MIN end
  if v > RLP.FONT_SCALE_MAX then v = RLP.FONT_SCALE_MAX end
  return v
end

local function ClampOffset(v)
  v = tonumber(v) or 0
  if v < RLP.OFFSET_MIN then v = RLP.OFFSET_MIN end
  if v > RLP.OFFSET_MAX then v = RLP.OFFSET_MAX end
  return v
end

-- Reads saved rank.color as RGB numbers. Accepts {r=,g=,b=} or {r,g,b},
-- and still understands an old saved name such as "RED".
local function GetRankColorRGB(rank)
  local c = rank and rank.color
  if type(c) == "table" then
    return tonumber(c.r) or tonumber(c[1]) or 0xFD / 255,
           tonumber(c.g) or tonumber(c[2]) or 0x9A / 255,
           tonumber(c.b) or tonumber(c[3]) or 0
  end
  local named = type(c) == "string" and RLP.rankColors[c]
  if named then return named[1], named[2], named[3] end
  return 0xFD / 255, 0x9A / 255, 0
end

-- Reads saved rank.manaCostColor as RGB numbers; falls back to mana blue.
local function GetManaColorRGB(rank)
  local c = rank and rank.manaCostColor
  if type(c) == "table" then
    return tonumber(c.r) or tonumber(c[1]) or 0x66 / 255,
           tonumber(c.g) or tonumber(c[2]) or 0xB3 / 255,
           tonumber(c.b) or tonumber(c[3]) or 1
  end
  return 0x66 / 255, 0xB3 / 255, 1
end
RLP.GetManaColorRGB = GetManaColorRGB

---------------------------------------------------------------------------
-- CUSTOM COLORED OUTLINE (added Nov 10, 2026)
-- The game's Normal/Max outline is always black. When the drop shadow is on
-- and its color is White or Light gray, the black outline is dropped and the
-- outline is drawn instead from copies of the text in the shadow color, each
-- 1 pixel apart around the main text: 8 copies (radius 1) for Normal, 16
-- (radius 1 and 2) for Max. The copies sit just under the main text and follow
-- its text, size, show and hide. Black shadow keeps the game's own outline.
-- To turn it off, set RLP.CUSTOM_OUTLINE = false (or restore
-- /tmp/gb_rlp_backup_pre_whiteoutline.lua).
---------------------------------------------------------------------------
RLP.CUSTOM_OUTLINE = true
-- Since Nov 10, 2026 (9 PM): the main text keeps the game's black outline at
-- all times, and the colored copies form a soft halo just OUTSIDE that black
-- edge, at about 60% strength. The game's outline is about 1 pixel wide for
-- Normal and about 2 for Max, so the ring sits one pixel past it:
--   Normal: 8 copies at 2 px (1 px past the outline).
--   Max:    8 copies at 2 px, plus 4 straight up/down/left/right at 3 px
--           (tightened from 3 and 4 at 9:15 PM).
RLP.OUTLINE_HALO_ALPHA = 0.6
RLP.OUTLINE_EDGE = { NORMAL = 1, MAX = 2 } -- reference only now; ring sizes are set by OUTLINE_RING_PX / OUTLINE_CARDINAL_PX below
local MAX_OUTLINE_COPIES = 12
-- Halo ring sizes in pixels (Nov 10, 2026, 9:15 PM: Max tightened from 3 and 4
-- to 2 and 3). RING is the 8-copy ring; CARDINAL adds 4 copies straight up,
-- down, left and right (none for Normal).
RLP.OUTLINE_RING_PX     = { NORMAL = 2, MAX = 2 }
RLP.OUTLINE_CARDINAL_PX = { MAX = 3 }
local function OutlineOffsets(thickness)
  local r = RLP.OUTLINE_RING_PX[thickness] or 2
  local t = { {-r,0},{r,0},{0,r},{0,-r},{-r,r},{r,r},{-r,-r},{r,-r} }
  local r2 = RLP.OUTLINE_CARDINAL_PX[thickness]
  if r2 then
    t[#t + 1] = { 0, r2 }; t[#t + 1] = { 0, -r2 }
    t[#t + 1] = { -r2, 0 }; t[#t + 1] = { r2, 0 }
  end
  return t
end

-- Max outline nudges (Nov 10, 2026). The game's thick outline adds about a
-- pixel of edge on every side, and a corner-pinned label grows away from its
-- corner, so the letters drift. Under Max only, these move the anchor so the
-- letters stay where they are under Normal and the thicker edge grows evenly
-- around them. Pixels; positive X is right, positive Y is up.
RLP.MAX_NUDGE_RANK_X = -1 -- rank label, lower left (and left center: X only)
RLP.MAX_NUDGE_RANK_Y = -1
RLP.MAX_NUDGE_MANA_X = -1 -- mana cost, top left (top center: Y only)
RLP.MAX_NUDGE_MANA_Y = 1

local function OutlineSync(fs)
  local copies = fs.rlpOutline
  if not copies then return end
  local text = fs:GetText() or ""
  local show = fs.rlpOutlineOn and fs:IsShown() and text ~= ""
  -- Anchor every copy exactly like the main text (same point, same frame, same
  -- offsets) plus its ring offset, not from the text's center, so copies and
  -- text always round to the same pixels on every button.
  local point, rel, relPoint, px, py = fs:GetPoint(1)
  local offs = fs.rlpOutlineOffsets or {}
  for i, c in ipairs(copies) do
    local o = offs[i]
    if point and o then
      c:ClearAllPoints()
      c:SetPoint(point, rel, relPoint, (px or 0) + o[1], (py or 0) + o[2])
    end
    c:SetText(text)
    if show and i <= (fs.rlpOutlineCount or 0) then c:Show() else c:Hide() end
  end
end

local function EnsureOutline(fs)
  if fs.rlpOutline then return fs.rlpOutline end
  local parent = fs:GetParent()
  -- Draw order: sublevels alone weren't enough to keep the copies under the
  -- text, so each gets its own frame. The copies go on a frame one level above
  -- the original parent, and the main text moves to a frame one level above
  -- that, so the text always draws on top of its outline.
  local base = parent:GetFrameLevel() or 0
  local outlineFrame = CreateFrame("Frame", nil, parent)
  outlineFrame:SetSize(1, 1)
  outlineFrame:SetPoint("BOTTOMLEFT", parent, "BOTTOMLEFT", 0, 0) -- corner, not center (whole pixels)
  outlineFrame:SetFrameLevel(base + 1)
  outlineFrame:EnableMouse(false)
  local textFrame = CreateFrame("Frame", nil, parent)
  textFrame:SetSize(1, 1)
  textFrame:SetPoint("BOTTOMLEFT", parent, "BOTTOMLEFT", 0, 0) -- corner, not center (whole pixels)
  textFrame:SetFrameLevel(base + 2)
  textFrame:EnableMouse(false)
  fs:SetParent(textFrame)
  fs:SetDrawLayer("OVERLAY", 7)
  fs.rlpOutlineFrame, fs.rlpTextFrame = outlineFrame, textFrame
  local copies = {}
  for i = 1, MAX_OUTLINE_COPIES do
    local c = outlineFrame:CreateFontString(nil, "OVERLAY", BASE_FONT_NAME)
    c:SetDrawLayer("OVERLAY", 6) -- on the lower frame, under the main text
    c:SetShadowOffset(0, 0)
    c:Hide()
    copies[i] = c
  end
  fs.rlpOutline = copies
  hooksecurefunc(fs, "SetText", OutlineSync)
  hooksecurefunc(fs, "Show", OutlineSync)
  hooksecurefunc(fs, "Hide", OutlineSync)
  return copies
end

-- shadow is a saved shadow section (db.rankShadow or db.manaShadow); rank's by default.
-- /ir outline: prints frame strata, frame levels and draw layers for the
-- first shown rank label (and mana cost text) and its halo copies, so the
-- order can be confirmed in game. Text should be on a higher frame level.
function RLP:PrintOutlineDebug()
  local p = "|cffffd100RLP outline|r "
  print(p .. "CUSTOM_OUTLINE=" .. tostring(self.CUSTOM_OUTLINE) .. " haloAlpha=" .. tostring(self.OUTLINE_HALO_ALPHA))
  local function report(which, fs)
    local _, size, flags = fs:GetFont()
    local layer, sub = fs:GetDrawLayer()
    local tf, of = fs:GetParent(), fs.rlpOutlineFrame
    print(p .. string.format("%s text=%s size=%s flags=%s layer=%s/%s textFrame strata=%s level=%s",
      which, tostring(fs:GetText()), tostring(size), tostring(flags), tostring(layer), tostring(sub),
      tostring(tf and tf.GetFrameStrata and tf:GetFrameStrata()), tostring(tf and tf.GetFrameLevel and tf:GetFrameLevel())))
    if not of then print(p .. which .. " has no halo copies (shadow Black or off)") return end
    local c = fs.rlpOutline and fs.rlpOutline[1]
    local cl, cs = c and c:GetDrawLayer()
    local shown = 0
    for _, cc in ipairs(fs.rlpOutline or {}) do if cc:IsShown() then shown = shown + 1 end end
    print(p .. string.format("%s halo frame strata=%s level=%s copyLayer=%s/%s copiesShown=%d of %s",
      which, tostring(of:GetFrameStrata()), tostring(of:GetFrameLevel()), tostring(cl), tostring(cs),
      shown, tostring(fs.rlpOutlineCount)))
  end
  for button, labels in pairs(self.labels or {}) do
    if labels.rank and labels.rank:IsVisible() and (labels.rank:GetText() or "") ~= "" then
      print(p .. "button " .. tostring(button.GetName and button:GetName() or "?"))
      report("rank", labels.rank)
      if labels.mana and labels.mana:IsVisible() then report("mana", labels.mana) end
      return
    end
  end
  print(p .. "no shown rank label found")
end

RLP.NO_SHADOW = { enabled = false } -- passed for text that should have no shadow or halo

function RLP:StyleText(fs, r, g, b, size, shadow)
  local rank = self.db.rank
  shadow = shadow or self.db.rankShadow or {}
  local flags = self.thicknessFlags[rank.thickness] or ""
  local fontSize = ClampScale(size or rank.fontScale)
  local sc = shadow.enabled and (self.shadowColors[shadow.color] or self.shadowColors.BLACK)
  local custom = self.CUSTOM_OUTLINE and sc and shadow.color ~= "BLACK" and shadow.color ~= nil
    and self.shadowColors[shadow.color] ~= nil
  -- The main text always keeps the game's black outline; with a white or light
  -- gray shadow the colored halo copies below sit just outside it.
  fs.rlpFontOK = SafeSetFont(fs, fontSize, flags) -- result kept for /irank debug
  fs:SetTextColor(r, g, b)
  if sc then
    fs:SetShadowColor(sc[1], sc[2], sc[3], 1)
    fs:SetShadowOffset(1, -1) -- was 3, -3, which read as a second copy of the text
  else
    fs:SetShadowOffset(0, 0)
  end
  if custom then
    local copies = EnsureOutline(fs)
    local offsets = OutlineOffsets(rank.thickness)
    fs.rlpOutlineCount = #offsets
    fs.rlpOutlineOffsets = offsets -- copies are anchored in OutlineSync, after the text is placed
    for i, c in ipairs(copies) do
      SafeSetFont(c, fontSize, "")
      c:SetTextColor(sc[1], sc[2], sc[3], self.OUTLINE_HALO_ALPHA)
      c:SetShadowOffset(0, 0)
    end
    fs.rlpOutlineOn = true
  else
    fs.rlpOutlineOn = false
  end
  OutlineSync(fs)
end

---------------------------------------------------------------------------
-- RANK TEXT (Spec 2, 6: Data source)
---------------------------------------------------------------------------
-- TEMPORARY DIAGNOSTIC: when true, every button's rank label shows "TEST"
-- at size 20, centered, with no offsets, whether or not a rank was found.
-- Set back to false (or restore the backup) once the test is done.
RLP.TEST_LABEL = false

-- TEMPORARY VISIBILITY DIAGNOSTIC: when true, a real rank label is redrawn
-- bright yellow at size 20 with an outline, and a small red square marks the
-- exact anchor point. Set to false (or restore the backup) when done.
RLP.DIAG_VISIBLE = false

-- TEMPORARY SHADOW DEBUG: when true, clicking the shadow checkbox or a shadow
-- color prints the saved setting and what the first shown rank label really has.
-- Set to false (or restore the backup) once the shadow is sorted out.
RLP.SHADOW_DEBUG = false -- turned off Nov 10, 2026 (was spamming chat); set true to bring the readout back

function RLP:PrintShadowDebug(which)
  if not self.SHADOW_DEBUG or not self.db then return end
  which = (which == "mana") and "mana" or "rank"
  local sh = (which == "mana" and self.db.manaShadow or self.db.rankShadow) or {}
  local want = sh.enabled and (self.shadowColors[sh.color] or self.shadowColors.BLACK)
  local p = "|cffffd100RLP " .. which .. " shadow|r "
  print(p .. "saved: shadow=" .. tostring(sh.enabled) .. " color=" .. tostring(sh.color)
    .. (want and string.format(" (%.2f, %.2f, %.2f)", want[1], want[2], want[3]) or ""))
  local found
  for button, labels in pairs(self.labels or {}) do
    local fs = labels and labels[which]
    if fs and fs:IsVisible() and (fs:GetText() or "") ~= "" then
      found = true
      local r, g, b, a = fs:GetShadowColor()
      local ox, oy = fs:GetShadowOffset()
      local _, size, flags = fs:GetFont()
      print(p .. string.format("applied on %s: shadow color=(%.2f, %.2f, %.2f, a=%.2f) offset=(%s, %s) size=%s flags=%s text=%s",
        tostring(button.GetName and button:GetName() or "?"), r or -1, g or -1, b or -1, a or -1,
        tostring(ox), tostring(oy), tostring(size), tostring(flags), tostring(fs:GetText())))
      break
    end
  end
  if not found then print(p .. "no shown " .. which .. " text found to read back") end
end

function RLP:ApplyRankText(button, labels, spellID, slot)
  local fs = labels.rank
  if self.TEST_LABEL then
    fs:SetFont(FONT_PATH, 20, "OUTLINE")
    fs:SetTextColor(1, 0, 0)
    fs:ClearAllPoints()
    fs:SetPoint("CENTER", button, "CENTER", 0, 0)
    fs:SetText("TEST")
    fs:Show()
    return
  end
  local n = slot and self:GetRankNumber(spellID, slot)
  if not n then
    fs:Hide()
    if labels.dot then labels.dot:Hide() end
    return
  end
  local rank = self.db.rank
  local r, g, b = GetRankColorRGB(rank)
  self:StyleText(fs, r, g, b)
  fs:ClearAllPoints()
  local x, y = ClampOffset(rank.offsetX), ClampOffset(rank.offsetY)
  local isMax = (rank.thickness == "MAX")
  if rank.position == "LEFTCENTER" then
    local nx = isMax and self.MAX_NUDGE_RANK_X or 0
    fs:SetPoint("LEFT", button, "LEFT", 2 + x + nx, y)
  else -- LOWERLEFT (default); never middle or upper-right
    local nx = isMax and self.MAX_NUDGE_RANK_X or 0
    local ny = isMax and self.MAX_NUDGE_RANK_Y or 0
    fs:SetPoint("BOTTOMLEFT", button, "BOTTOMLEFT", 2 + x + nx, 2 + y + ny)
  end
  fs:SetText("R" .. n)
  fs:Show()
  if self.DIAG_VISIBLE then
    fs.rlpDiagFontOK = fs:SetFont(FONT_PATH, 20, "OUTLINE")
    fs:SetTextColor(1, 1, 0)
    if not labels.dot then
      labels.dot = button:CreateTexture(nil, "OVERLAY")
      labels.dot:SetSize(4, 4)
    end
    labels.dot:SetColorTexture(1, 0, 0, 1)
    labels.dot:ClearAllPoints()
    if rank.position == "LEFTCENTER" then
      labels.dot:SetPoint("CENTER", button, "LEFT", 2 + x, y)
    else
      labels.dot:SetPoint("CENTER", button, "BOTTOMLEFT", 2 + x, 2 + y)
    end
    labels.dot:Show()
  elseif labels.dot then
    labels.dot:Hide()
  end
end

---------------------------------------------------------------------------
-- MANA COST TEXT (Spec 3)
-- Upper-left corner. Only when the checkbox is on. Nothing for no-cost spells.
---------------------------------------------------------------------------
function RLP:ApplyManaText(button, labels, spellID)
  local fs = labels.mana
  local cost = spellID and self.db.mana.enabled and self:GetManaCost(spellID)
  if not cost then fs:Hide() return end
  local mr, mg, mb = GetManaColorRGB(self.db.rank)
  self:StyleText(fs, mr, mg, mb, self.db.rank.manaFontScale or self.db.rank.fontScale, self.db.manaShadow)
  fs:ClearAllPoints()
  local mp = self.db.manaPos or {}
  local x, y = ClampOffset(mp.offsetX), ClampOffset(mp.offsetY)
  local isMax = (self.db.rank.thickness == "MAX")
  local ny = isMax and self.MAX_NUDGE_MANA_Y or 0
  if mp.position == "TOPCENTER" then
    fs:SetPoint("TOP", button, "TOP", x, -2 + y + ny)
  else -- TOPLEFT (default)
    local nx = isMax and self.MAX_NUDGE_MANA_X or 0
    fs:SetPoint("TOPLEFT", button, "TOPLEFT", 2 + x + nx, -2 + y + ny)
  end
  fs:SetText(cost)
  fs:Show()
end

---------------------------------------------------------------------------
-- DURATION TEXT (Spec 4)
-- Centered above the icon. Static tooltip duration for that rank.
-- No live countdown and no timer.
---------------------------------------------------------------------------
function RLP:ApplyDurationText(button, labels, spellID)
  local fs = labels.duration
  local text = spellID and self.db.duration.enabled and self:GetStaticDuration(spellID)
  if not text then fs:Hide() return end
  -- Duration text never gets the drop shadow or the colored halo; those are
  -- for the rank and mana cost labels only (changed Nov 10, 2026).
  self:StyleText(fs, 1, 1, 1, nil, RLP.NO_SHADOW)
  fs:SetText(text)
  -- Whole-pixel placement: pin the left edge at the button's center minus half
  -- the text width, rounded down, so it can't drift half a pixel when the
  -- width changes between even and odd (e.g. switching Normal and Max).
  local w = fs:GetStringWidth() or 0
  fs:ClearAllPoints()
  fs:SetPoint("BOTTOMLEFT", button, "TOP", -math.floor(w / 2), 2)
  fs:Show()
end

---------------------------------------------------------------------------
-- REFRESH (Spec 6: Footprint)
-- Update only when something changes, never every frame, and only out of
-- combat. Changes during combat are applied when combat ends.
---------------------------------------------------------------------------
function RLP:RefreshButton(button)
  local spellID, slot = self:GetButtonSpell(button)
  local labels = self.labels[button]
  if not labels then
    -- No label for buttons that have never shown a ranked spell.
    if not self.TEST_LABEL and not (slot and self:GetRankNumber(spellID, slot)) then return end
    labels = self:CreateLabels(button)
    if not labels then return end
  end
  -- Keep the rank label's holder frame matched to the button right now.
  if labels.holder then
    if button:IsVisible() then labels.holder:Show() else labels.holder:Hide() end
  end
  self:ApplyRankText(button, labels, spellID, slot)
  self:ApplyManaText(button, labels, spellID)
  self:ApplyDurationText(button, labels, spellID)
end

-- Per-button hooks: refresh one button when its action or page changes.
-- HookScript only adds a follow-up handler; it never replaces secure code.
RLP.hooked = {}
local function OnButtonChanged(button, name)
  if name and name ~= "action" and name ~= "state" then return end
  if InCombatLockdown() then RLP.pendingRefresh = true return end
  RLP:RefreshButton(button)
end
function RLP:HookButton(button)
  if self.hooked[button] then return end
  self.hooked[button] = true
  button:HookScript("OnAttributeChanged", OnButtonChanged)
  button:HookScript("OnShow", OnButtonChanged)
end

function RLP:RefreshAll()
  if not self.db then return end
  if InCombatLockdown() then
    self.pendingRefresh = true
    return
  end
  self.pendingRefresh = false
  local active, usingBartender = self:GetActiveButtons()
  for _, button in ipairs(active) do self:HookButton(button) self:RefreshButton(button) end
  if usingBartender then
    -- Blizzard's buttons are hidden behind Bartender's; hide any labels left on them.
    for _, button in ipairs(self:GetBlizzardButtons()) do
      local labels = self.labels[button]
      if labels then
        if labels.holder then labels.holder:Hide() end
        labels.rank:Hide() labels.mana:Hide() labels.duration:Hide()
      end
    end
  end
end

---------------------------------------------------------------------------
-- SETTINGS PANEL (Spec 5)
-- Movable window opened by /irank and /ir. Also listed in the game's
-- AddOns options. Every control writes to RankLabelPlusDB and refreshes
-- labels right away (or when combat ends, through RefreshAll).
---------------------------------------------------------------------------
local function CopyTable(src)
  local t = {}
  for k, v in pairs(src) do
    if type(v) == "table" then t[k] = CopyTable(v) else t[k] = v end
  end
  return t
end

local function RadioLabel(btn)
  return btn.text or btn.Text
end

local function SetButtonEnabled(btn, enabled)
  if btn.SetEnabled then
    btn:SetEnabled(enabled)
  elseif enabled then
    btn:Enable()
  else
    btn:Disable()
  end
  local fs = RadioLabel(btn)
  if fs then
    if enabled then
      fs:SetFontObject(GameFontNormalSmall)
    elseif GameFontDisableSmall then
      fs:SetFontObject(GameFontDisableSmall)
    else
      fs:SetTextColor(0.5, 0.5, 0.5)
    end
  end
end

local function SetRadioGroup(group, selected)
  for value, btn in pairs(group) do
    btn:SetChecked(value == selected)
  end
end

function RLP:ApplySettings()
  if not self.db then return end
  local rank = self.db.rank
  rank.offsetX = ClampOffset(rank.offsetX)
  rank.offsetY = ClampOffset(rank.offsetY)
  rank.fontScale = ClampScale(rank.fontScale)
  rank.manaFontScale = ClampScale(rank.manaFontScale or 11)
  local mp = self.db.manaPos
  if mp then
    mp.offsetX = ClampOffset(mp.offsetX)
    mp.offsetY = ClampOffset(mp.offsetY)
    -- Earlier test builds saved "UPPERLEFT" or "LEFTCENTER"; both become Top left.
    if mp.position ~= "TOPLEFT" and mp.position ~= "TOPCENTER" then mp.position = "TOPLEFT" end
  end
  self:RefreshAll()
  if self.SyncSettingsPanel then self:SyncSettingsPanel() end
end

-- Every group of user settings. "Save as new default" copies all of these.
RLP.SETTING_KEYS = { "rank", "mana", "duration", "rankShadow", "manaShadow", "manaPos" }

-- Your own saved defaults (from "Save as new default") live in the saved
-- variables as RankLabelPlusDB.userDefaults, because an add-on can't rewrite
-- its own Lua file. When none are saved, the built-in defaults above are used.
function RLP:GetActiveDefaults(key)
  local ud = self.db and self.db.userDefaults
  if type(ud) == "table" and type(ud[key]) == "table" then return ud[key] end
  return self.defaults[key]
end

function RLP:SaveAsDefaults()
  if not self.db then return end
  local ud = {}
  for _, key in ipairs(self.SETTING_KEYS) do
    if type(self.db[key]) == "table" then ud[key] = CopyTable(self.db[key]) end
  end
  self.db.userDefaults = ud
  print("|cffFD9A00Rank Label Plus:|r current settings saved as your new defaults. Reset to defaults now returns here. (/ir factory restores the original defaults.)")
end

function RLP:ClearSavedDefaults()
  if not self.db then return end
  self.db.userDefaults = nil
  print("|cffFD9A00Rank Label Plus:|r your saved defaults were cleared. Reset to defaults now uses the original built-in defaults.")
end

function RLP:ResetSettings()
  if not self.db then return end
  for _, key in ipairs(self.SETTING_KEYS) do
    self.db[key] = CopyTable(self:GetActiveDefaults(key))
  end
  -- Fill anything a saved default is missing (e.g. a setting added in a later
  -- version) from the built-in defaults.
  ApplyDefaults(self.db, self.defaults)
  self:ApplySettings()
end

-- key is the saved setting to write ("color" by default, or "manaCostColor");
-- swatchKey is the panel swatch texture to update ("swatchTex" by default).
local function OpenColorPicker(r, g, b, key, swatchKey)
  key = key or "color"
  swatchKey = swatchKey or "swatchTex"
  local function apply(nr, ng, nb)
    if not RLP.db then return end
    RLP.db.rank[key] = { r = nr, g = ng, b = nb }
    if RLP.panel and RLP.panel[swatchKey] then
      RLP.panel[swatchKey]:SetColorTexture(nr, ng, nb, 1)
    end
    RLP:RefreshAll()
  end
  local function onChanged()
    local nr, ng, nb = ColorPickerFrame:GetColorRGB()
    apply(nr, ng, nb)
  end
  local function onCancel(restore)
    if type(restore) ~= "table" then return end
    apply(restore.r or restore[1] or 1, restore.g or restore[2] or 0, restore.b or restore[3] or 0)
  end
  if ColorPickerFrame.SetupColorPickerAndShow then
    ColorPickerFrame:SetupColorPickerAndShow({
      r = r, g = g, b = b,
      hasOpacity = false,
      swatchFunc = onChanged,
      cancelFunc = onCancel,
    })
  else
    ColorPickerFrame.func = onChanged
    ColorPickerFrame.opacityFunc = nil
    ColorPickerFrame.cancelFunc = onCancel
    ColorPickerFrame.hasOpacity = false
    ColorPickerFrame.previousValues = { r = r, g = g, b = b }
    ColorPickerFrame:SetColorRGB(r, g, b)
    if ShowUIPanel then
      ShowUIPanel(ColorPickerFrame)
    else
      ColorPickerFrame:Hide()
      ColorPickerFrame:Show()
    end
  end
end

function RLP:SyncSettingsPanel()
  local f = self.panel
  if not (f and self.db) then return end
  local rank = self.db.rank
  self.panelSyncing = true
  local r, g, b = GetRankColorRGB(rank)
  if f.swatchTex then f.swatchTex:SetColorTexture(r, g, b, 1) end
  if f.manaSwatchTex then
    local mr, mg, mb = GetManaColorRGB(rank)
    f.manaSwatchTex:SetColorTexture(mr, mg, mb, 1)
  end
  if f.sizeSlider then
    f.sizeSlider:SetValue(ClampScale(rank.fontScale))
    if f.sizeSlider.Text then f.sizeSlider.Text:SetText(tostring(math.floor(ClampScale(rank.fontScale) + 0.5))) end
  end
  if f.manaSizeSlider then
    local v = ClampScale(rank.manaFontScale or 11)
    f.manaSizeSlider:SetValue(v)
    if f.manaSizeSlider.Text then f.manaSizeSlider.Text:SetText(tostring(math.floor(v + 0.5))) end
  end
  if f.outlineRadios then SetRadioGroup(f.outlineRadios, rank.thickness or "MAX") end
  for _, grp in ipairs({ { f.shadowCheck, f.shadowRadios, self.db.rankShadow },
                         { f.manaShadowCheck, f.manaShadowRadios, self.db.manaShadow } }) do
    local check, radios, sh = grp[1], grp[2], grp[3] or {}
    if check then check:SetChecked(sh.enabled and true or false) end
    if radios then
      SetRadioGroup(radios, sh.color or "BLACK")
      for _, btn in pairs(radios) do
        SetButtonEnabled(btn, sh.enabled and true or false)
      end
    end
  end
  if f.positionRadios then SetRadioGroup(f.positionRadios, rank.position or "LOWERLEFT") end
  if f.manaPositionRadios and self.db.manaPos then
    local mp = self.db.manaPos
    SetRadioGroup(f.manaPositionRadios, mp.position or "TOPLEFT")
    if f.manaOffsetText then
      f.manaOffsetText:SetText(string.format("X %d, Y %d", ClampOffset(mp.offsetX), ClampOffset(mp.offsetY)))
    end
  end
  if f.offsetText then
    f.offsetText:SetText(string.format("X %d, Y %d", ClampOffset(rank.offsetX), ClampOffset(rank.offsetY)))
  end
  if f.manaCheck then f.manaCheck:SetChecked(self.db.mana.enabled and true or false) end
  if f.durationCheck then f.durationCheck:SetChecked(self.db.duration.enabled and true or false) end
  self.panelSyncing = false
end

function RLP:CreateSettingsPanel()
  if self.panel then return end

  local f = CreateFrame("Frame", "RankLabelPlusOptions", UIParent, "UIPanelDialogTemplate")
  f:SetSize(500, 640) -- 16px of the old Extras-to-Reset gap is spread as 4px between each section above
  f:SetPoint("CENTER")
  f:SetFrameStrata("DIALOG")
  f:SetToplevel(true)
  f:EnableMouse(true)
  f:SetMovable(true)
  f:SetClampedToScreen(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", function(self) self:StartMoving() end)
  f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
  if f.Title then f.Title:SetText("Rank Label Plus") end
  -- Panel background: medium tan / parchment instead of the template's black.
  -- A solid color is used because it can't fail to load the way a missing texture file would.
  local dialogBG = _G["RankLabelPlusOptionsDialogBG"]
  if dialogBG and dialogBG.SetColorTexture then
    dialogBG:SetTexCoord(0, 1, 0, 1)
    dialogBG:SetColorTexture(0.76, 0.64, 0.47, 1) -- medium tan
  end
  -- Close button inside the window's upper-right corner, at the template's
  -- standard spot (TOPRIGHT -2, -4), in front of the border art.
  local closeBtn = _G["RankLabelPlusOptionsClose"] or f.CloseButton
  if closeBtn then
    closeBtn:ClearAllPoints()
    closeBtn:SetPoint("TOPRIGHT", f, "TOPRIGHT", -2, -4)
    closeBtn:SetFrameLevel(f:GetFrameLevel() + 5)
  end

  -- Forever-themed chrome: bronze-gold border, bronze title bar, gold title
  -- with ornaments, an inner bronze frame with corner jewels, and soft
  -- darkened parchment edges. All solid colors and tints, no extra files.
  local PANEL_W = 500
  local GOLD = { 1, 0.82, 0 }
  local BRONZE = { 0.80, 0.58, 0.25 }
  local DARK_BRONZE = { 0.33, 0.20, 0.07 }
  for _, part in ipairs({ "TopLeft", "TopRight", "Top", "BottomLeft", "BottomRight", "Bottom", "Left", "Right" }) do
    local tex = _G["RankLabelPlusOptions" .. part]
    if tex and tex.SetVertexColor then tex:SetVertexColor(1, 0.80, 0.45) end
  end
  local titleBG = _G["RankLabelPlusOptionsTitleBG"]
  if titleBG and titleBG.SetVertexColor then titleBG:SetVertexColor(0.60, 0.36, 0.14) end

  local function Diamond(size, r, g, b, layer)
    local d = f:CreateTexture(nil, layer or "OVERLAY")
    d:SetSize(size, size)
    d:SetColorTexture(r, g, b, 1)
    if d.SetRotation then d:SetRotation(math.pi / 4) end
    return d
  end
  local function Line(r, g, b, a, layer)
    local t = f:CreateTexture(nil, layer or "ARTWORK")
    t:SetColorTexture(r, g, b, a or 1)
    return t
  end

  if f.Title then
    f.Title:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
    local tw = (f.Title.GetStringWidth and f.Title:GetStringWidth()) or 100
    -- The template's title sits between x 12 and width-32, so its center is 10px left of the frame's.
    local tl = Diamond(6, GOLD[1], GOLD[2], GOLD[3])
    tl:SetPoint("CENTER", f, "TOP", -10 - tw / 2 - 10, -15)
    local tr = Diamond(6, GOLD[1], GOLD[2], GOLD[3])
    tr:SetPoint("CENTER", f, "TOP", -10 + tw / 2 + 10, -15)
  end

  -- Soft darker edges on the parchment (inside the template background area).
  local function Shade(p1, x1, y1, p2, x2, y2)
    local t = Line(0.30, 0.18, 0.06, 0.22, "BORDER")
    t:SetPoint(p1, f, p1, x1, y1)
    t:SetPoint(p2, f, p2, x2, y2)
    return t
  end
  Shade("TOPLEFT", 8, -24, "TOPRIGHT", -6, -34)
  Shade("BOTTOMLEFT", 8, 18, "BOTTOMRIGHT", -6, 8)
  Shade("TOPLEFT", 8, -34, "BOTTOMLEFT", 18, 18)
  Shade("TOPRIGHT", -16, -34, "BOTTOMRIGHT", -6, 18)

  -- Inner bronze frame with a dark engraved line inside it, and corner jewels.
  local IN_L, IN_T, IN_R, IN_B = 12, -28, -10, 12
  local function Frame1(off, r, g, b)
    local top = Line(r, g, b, 1)
    top:SetPoint("TOPLEFT", f, "TOPLEFT", IN_L + off, IN_T - off)
    top:SetPoint("TOPRIGHT", f, "TOPRIGHT", IN_R - off, IN_T - off)
    top:SetHeight(1)
    local bot = Line(r, g, b, 1)
    bot:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", IN_L + off, IN_B + off)
    bot:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", IN_R - off, IN_B + off)
    bot:SetHeight(1)
    local left = Line(r, g, b, 1)
    left:SetPoint("TOPLEFT", f, "TOPLEFT", IN_L + off, IN_T - off)
    left:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", IN_L + off, IN_B + off)
    left:SetWidth(1)
    local right = Line(r, g, b, 1)
    right:SetPoint("TOPRIGHT", f, "TOPRIGHT", IN_R - off, IN_T - off)
    right:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", IN_R - off, IN_B + off)
    right:SetWidth(1)
  end
  Frame1(0, BRONZE[1], BRONZE[2], BRONZE[3])
  Frame1(1, DARK_BRONZE[1], DARK_BRONZE[2], DARK_BRONZE[3])
  for _, c in ipairs({ { "TOPLEFT", IN_L, IN_T }, { "TOPRIGHT", IN_R, IN_T }, { "BOTTOMLEFT", IN_L, IN_B }, { "BOTTOMRIGHT", IN_R, IN_B } }) do
    local outer = Diamond(9, DARK_BRONZE[1], DARK_BRONZE[2], DARK_BRONZE[3])
    outer:SetPoint("CENTER", f, c[1], c[2], c[3])
    local inner = Diamond(5, GOLD[1], GOLD[2], GOLD[3])
    inner:SetPoint("CENTER", f, c[1], c[2], c[3])
  end
  f:Hide()
  if UISpecialFrames then
    table.insert(UISpecialFrames, f:GetName())
  end
  f:SetScript("OnShow", function() RLP:SyncSettingsPanel() end)
  self.panel = f

  -- Section header: centered gold title with a jewel on each side and a
  -- divider bar on each side running out to small end jewels.
  -- Each bar is drawn as three stacked strips, built the same way for every
  -- section: a soft gold glow line, a 2-pixel brown core, and another gold
  -- glow line. Strips are placed on whole screen pixels (PixelUtil when the
  -- client has it) so no divider gets blended lighter than another.
  local GLOW = { 1, 0.82, 0, 0.75 }
  local CORE = { 0.45, 0.28, 0.10, 1 }
  local function PxPoint(region, point, rel, relPoint, x, y)
    if PixelUtil and PixelUtil.SetPoint then
      PixelUtil.SetPoint(region, point, rel, relPoint, x, y)
    else
      region:SetPoint(point, rel, relPoint, x, y)
    end
  end
  local function PxSize(region, w, h)
    if PixelUtil and PixelUtil.SetSize then
      PixelUtil.SetSize(region, w, h, 1, 1)
    else
      region:SetSize(w, h)
    end
  end
  -- Header(text, y [, spanX1, spanX2]): the divider runs from spanX1 to spanX2
  -- (window-relative x), with the title centered in that span. Default is the
  -- full width (24 to PANEL_W - 24); pass a half span for side-by-side headings.
  local function Header(text, y, spanX1, spanX2)
    spanX1 = spanX1 or 24
    spanX2 = spanX2 or (PANEL_W - 24)
    local center = math.floor((spanX1 + spanX2) / 2)
    local fs = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    fs:SetPoint("TOP", f, "TOPLEFT", center, y)
    fs:SetJustifyH("CENTER")
    fs:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
    fs:SetShadowColor(0, 0, 0, 1)
    fs:SetShadowOffset(1, -1)
    -- Multi-line titles ("Rank\npositioning"): measure the widest line so the
    -- divider gap fits it, and center the divider on the whole block.
    local sw, lineCount = 0, 0
    for line in string.gmatch(text, "[^\n]+") do
      fs:SetText(line)
      sw = math.max(sw, (fs.GetStringWidth and fs:GetStringWidth()) or 60)
      lineCount = lineCount + 1
    end
    fs:SetText(text)
    local half = math.floor(sw / 2 + 0.5)
    local strips = { { GLOW, 0, 1 }, { CORE, -1, 2 }, { GLOW, -3, 1 } }
    if lineCount > 1 then
      -- Multi-line title: one continuous divider under the last line, across
      -- the whole span, with tip diamonds at both ends and a center jewel.
      local barTop = y - 14 * lineCount -- whole-number offset, below the last row
      local w = spanX2 - spanX1
      for _, st in ipairs(strips) do
        local c = st[1]
        local t = Line(c[1], c[2], c[3], c[4])
        PxSize(t, w, st[3])
        PxPoint(t, "TOPLEFT", f, "TOPLEFT", spanX1, barTop + st[2])
      end
      Diamond(4, GOLD[1], GOLD[2], GOLD[3]):SetPoint("CENTER", f, "TOPLEFT", spanX1, barTop - 2)
      Diamond(4, GOLD[1], GOLD[2], GOLD[3]):SetPoint("CENTER", f, "TOPLEFT", spanX2, barTop - 2)
      Diamond(6, GOLD[1], GOLD[2], GOLD[3]):SetPoint("CENTER", f, "TOPLEFT", center, barTop - 2)
      return fs
    end
    local barTop = y - 4 -- whole-number offset from the window top, the same for every section
    local leftX1, leftX2 = spanX1, center - half - 16
    local rightX1, rightX2 = center + half + 16, spanX2
    for _, span in ipairs({ { leftX1, leftX2, "LEFT" }, { rightX1, rightX2, "RIGHT" } }) do
      local x1, x2 = span[1], span[2]
      local w = math.max(20, x2 - x1)
      if span[3] == "LEFT" then x1 = x2 - w end
      for _, st in ipairs(strips) do
        local c = st[1]
        local t = Line(c[1], c[2], c[3], c[4])
        PxSize(t, w, st[3])
        PxPoint(t, "TOPLEFT", f, "TOPLEFT", x1, barTop + st[2])
      end
      local tip = Diamond(4, GOLD[1], GOLD[2], GOLD[3])
      tip:SetPoint("CENTER", f, "TOPLEFT", span[3] == "LEFT" and x1 or (x1 + w), barTop - 2)
      local jewel = Diamond(6, GOLD[1], GOLD[2], GOLD[3])
      jewel:SetPoint("CENTER", f, "TOPLEFT", span[3] == "LEFT" and (center - half - 8) or (center + half + 8), barTop - 2)
    end
    return fs
  end

  local function MakeRadio(label, x, y, onPick)
    local btn = CreateFrame("CheckButton", nil, f, "UIRadioButtonTemplate")
    btn:SetPoint("TOPLEFT", x, y)
    local fs = RadioLabel(btn)
    if fs then fs:SetText(label) end
    btn:SetScript("OnClick", function()
      if RLP.panelSyncing then return end
      onPick()
      RLP:ApplySettings()
    end)
    return btn
  end

  -- Text
  Header("Text color selection", -36)
  local colorLabel = f:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
  colorLabel:SetPoint("TOPLEFT", 24, -62)
  colorLabel:SetText("Rank color")

  local swatch = CreateFrame("Button", nil, f)
  swatch:SetSize(24, 24)
  swatch:SetPoint("LEFT", colorLabel, "RIGHT", 10, 0)
  local swatchBorder = swatch:CreateTexture(nil, "BACKGROUND")
  swatchBorder:SetAllPoints()
  swatchBorder:SetColorTexture(0.1, 0.1, 0.1, 1)
  local swatchTex = swatch:CreateTexture(nil, "ARTWORK")
  swatchTex:SetPoint("TOPLEFT", 1, -1)
  swatchTex:SetPoint("BOTTOMRIGHT", -1, 1)
  swatchTex:SetColorTexture(0xFD / 255, 0x9A / 255, 0, 1)
  f.swatchTex = swatchTex
  swatch:SetScript("OnClick", function()
    local r, g, b = GetRankColorRGB(RLP.db and RLP.db.rank)
    OpenColorPicker(r, g, b)
  end)

  -- Mana cost color, same full color picker, beside Rank color.
  local manaColorLabel = f:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
  manaColorLabel:SetPoint("TOPLEFT", 210, -62)
  manaColorLabel:SetText("Mana cost color")
  local manaSwatch = CreateFrame("Button", nil, f)
  manaSwatch:SetSize(24, 24)
  manaSwatch:SetPoint("LEFT", manaColorLabel, "RIGHT", 10, 0)
  local manaSwatchBorder = manaSwatch:CreateTexture(nil, "BACKGROUND")
  manaSwatchBorder:SetAllPoints()
  manaSwatchBorder:SetColorTexture(0.1, 0.1, 0.1, 1)
  local manaSwatchTex = manaSwatch:CreateTexture(nil, "ARTWORK")
  manaSwatchTex:SetPoint("TOPLEFT", 1, -1)
  manaSwatchTex:SetPoint("BOTTOMRIGHT", -1, 1)
  manaSwatchTex:SetColorTexture(0x66 / 255, 0xB3 / 255, 1, 1)
  f.manaSwatchTex = manaSwatchTex
  manaSwatch:SetScript("OnClick", function()
    local r, g, b = GetManaColorRGB(RLP.db and RLP.db.rank)
    OpenColorPicker(r, g, b, "manaCostColor", "manaSwatchTex")
  end)

  -- Color row laid out exactly like the Extras row: each control is its box
  -- (here the color swatch) with the label just to its right, and the two
  -- pairs are centered together in the window with the same 36px gap.
  do
    local BOX, LABEL_GAP, PAIR_GAP = 24, 6, 36
    local wa = (colorLabel.GetStringWidth and colorLabel:GetStringWidth()) or 70
    local wb = (manaColorLabel.GetStringWidth and manaColorLabel:GetStringWidth()) or 105
    if wa < 1 then wa = 70 end
    if wb < 1 then wb = 105 end
    local firstW = BOX + LABEL_GAP + wa
    local total = firstW + PAIR_GAP + BOX + LABEL_GAP + wb
    local startX = math.floor((PANEL_W - total) / 2 + 0.5)
    local ROW_Y = -58 -- swatch top; labels center on the swatch
    swatch:ClearAllPoints()
    swatch:SetPoint("TOPLEFT", f, "TOPLEFT", startX, ROW_Y)
    colorLabel:ClearAllPoints()
    colorLabel:SetPoint("LEFT", swatch, "RIGHT", LABEL_GAP, 0)
    manaSwatch:ClearAllPoints()
    manaSwatch:SetPoint("TOPLEFT", f, "TOPLEFT", math.floor(startX + firstW + PAIR_GAP + 0.5), ROW_Y)
    manaColorLabel:ClearAllPoints()
    manaColorLabel:SetPoint("LEFT", manaSwatch, "RIGHT", LABEL_GAP, 0)
  end

  -- Text size
  -- Text size (left half) and Outline (right half) share one row.
  local ROW_HALF = math.floor(PANEL_W / 2)
  Header("Text size", -102, 24, ROW_HALF - 8)
  Header("Outline", -102, ROW_HALF + 8, PANEL_W - 24)
  local slider = CreateFrame("Slider", "RankLabelPlusFontScaleSlider", f, "OptionsSliderTemplate")
  slider:SetWidth(197) -- x 31 to 228; the 2 and the 36 overhang the Text size divider ends (24 / 242) equally
  slider:SetPoint("TOPLEFT", 31, -138)
  slider:SetMinMaxValues(RLP.FONT_SCALE_MIN, RLP.FONT_SCALE_MAX)
  slider:SetValueStep(1)
  if slider.SetObeyStepOnDrag then slider:SetObeyStepOnDrag(true) end
  -- Min and max sit flush against the two ends of the bar, level with it,
  -- instead of tucked underneath.
  if slider.Low then
    slider.Low:SetText("2")
    slider.Low:ClearAllPoints()
    slider.Low:SetPoint("RIGHT", slider, "LEFT", -3, 0)
  end
  if slider.High then
    slider.High:SetText("36")
    slider.High:ClearAllPoints()
    slider.High:SetPoint("LEFT", slider, "RIGHT", 3, 0)
  end
  if slider.Text then slider.Text:SetText("13") end
  slider:SetScript("OnValueChanged", function(self, value)
    if RLP.panelSyncing or not RLP.db then return end
    value = ClampScale(value)
    RLP.db.rank.fontScale = value
    if self.Text then self.Text:SetText(tostring(math.floor(value + 0.5))) end
    RLP:RefreshAll()
  end)
  f.sizeSlider = slider
  local sizeName = f:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
  sizeName:SetPoint("TOP", slider, "BOTTOM", 0, -1) -- centered under the bar
  sizeName:SetText("Rank size")

  -- Mana cost text size, separate from the rank size above.
  local manaSlider = CreateFrame("Slider", "RankLabelPlusManaScaleSlider", f, "OptionsSliderTemplate")
  manaSlider:SetWidth(197) -- x 31 to 228; the 2 and the 36 overhang the Text size divider ends (24 / 242) equally
  manaSlider:SetPoint("TOPLEFT", 31, -180)
  manaSlider:SetMinMaxValues(RLP.FONT_SCALE_MIN, RLP.FONT_SCALE_MAX)
  manaSlider:SetValueStep(1)
  if manaSlider.SetObeyStepOnDrag then manaSlider:SetObeyStepOnDrag(true) end
  -- Min and max sit flush against the two ends of the bar, level with it,
  -- instead of tucked underneath.
  if manaSlider.Low then
    manaSlider.Low:SetText("2")
    manaSlider.Low:ClearAllPoints()
    manaSlider.Low:SetPoint("RIGHT", manaSlider, "LEFT", -3, 0)
  end
  if manaSlider.High then
    manaSlider.High:SetText("36")
    manaSlider.High:ClearAllPoints()
    manaSlider.High:SetPoint("LEFT", manaSlider, "RIGHT", 3, 0)
  end
  if manaSlider.Text then manaSlider.Text:SetText("11") end
  manaSlider:SetScript("OnValueChanged", function(self, value)
    if RLP.panelSyncing or not RLP.db then return end
    value = ClampScale(value)
    RLP.db.rank.manaFontScale = value
    if self.Text then self.Text:SetText(tostring(math.floor(value + 0.5))) end
    RLP:RefreshAll()
  end)
  f.manaSizeSlider = manaSlider
  local manaSizeName = f:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
  manaSizeName:SetPoint("TOP", manaSlider, "BOTTOM", 0, -1) -- centered under the bar
  manaSizeName:SetText("Mana cost size")

  -- Outline choices: Normal and Max side by side, the pair centered left to
  -- right in the Outline half and up and down between the two size bars.
  f.outlineRadios = {}
  f.outlineRadios.NORMAL = MakeRadio("Normal", ROW_HALF + 30, -156, function() RLP.db.rank.thickness = "NORMAL" end)
  f.outlineRadios.MAX    = MakeRadio("Max", ROW_HALF + 130, -156, function() RLP.db.rank.thickness = "MAX" end)
  do
    local BTN, LABEL_GAP, PAIR_GAP = 16, 4, 32
    local OUT_Y = -156 -- 16px radios centered at y -164, midway in the Outline area
    local fa, fb = RadioLabel(f.outlineRadios.NORMAL), RadioLabel(f.outlineRadios.MAX)
    local wa = (fa and fa.GetStringWidth and fa:GetStringWidth()) or 44
    local wb = (fb and fb.GetStringWidth and fb:GetStringWidth()) or 26
    if wa < 1 then wa = 44 end
    if wb < 1 then wb = 26 end
    local firstW = BTN + LABEL_GAP + wa
    local total = firstW + PAIR_GAP + BTN + LABEL_GAP + wb
    local x1, x2 = ROW_HALF + 8, PANEL_W - 24 -- the Outline heading's span
    local startX = math.floor(x1 + ((x2 - x1) - total) / 2 + 0.5)
    f.outlineRadios.NORMAL:ClearAllPoints()
    f.outlineRadios.NORMAL:SetPoint("TOPLEFT", f, "TOPLEFT", startX, OUT_Y)
    f.outlineRadios.MAX:ClearAllPoints()
    f.outlineRadios.MAX:SetPoint("TOPLEFT", f, "TOPLEFT", math.floor(startX + firstW + PAIR_GAP + 0.5), OUT_Y)
  end

  -- Shadow
  Header("Shadow", -216)
  -- One block per text type: its own on/off checkbox and four colors in two rows of two.
  -- dbKey is the saved section ("rankShadow" or "manaShadow"); which is for the debug print.
  -- One block per text type: its own on/off checkbox and four colors in two
  -- rows of two, inside a rounded bronze box. Rank sits on the left and mana
  -- cost on the right. dbKey is the saved section ("rankShadow" or
  -- "manaShadow"); which is for the debug print. Labels in the boxes use the
  -- small font so two columns fit in each half of the window.
  -- Box sizes are worked out from the real label widths after the text is
  -- set, so nothing clips: both boxes get the width of the wider one.
  local BLOCK_MIN_W, BLOCK_H, BLOCK_GAP, PAD = 210, 86, 12, 12
  local RADIO_W, COL_GAP = 20, 18
  local function SmallLabel(fs)
    if fs and fs.SetFontObject and GameFontHighlightSmall then fs:SetFontObject(GameFontHighlightSmall) end
  end
  local function TextW(fs, fallback)
    return (fs and fs.GetStringWidth and fs:GetStringWidth()) or fallback
  end
  local function ShadowBlock(label, dbKey, which)
    local box = CreateFrame("Frame", nil, f, BackdropTemplateMixin and "BackdropTemplate" or nil)
    box:SetFrameLevel(f:GetFrameLevel()) -- behind the controls, which sit one level up
    if box.SetBackdrop then
      box:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", -- rounded corners
        tile = true, tileSize = 16, edgeSize = 12,
        insets = { left = 3, right = 3, top = 3, bottom = 3 },
      })
      box:SetBackdropColor(0.30, 0.18, 0.06, 0.18)
      box:SetBackdropBorderColor(BRONZE[1], BRONZE[2], BRONZE[3], 1)
    end

    local check = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
    check:SetSize(26, 26)
    local cfs = RadioLabel(check)
    SmallLabel(cfs)
    if cfs then cfs:SetText(label) end
    check:SetScript("OnClick", function(self)
      if RLP.panelSyncing or not RLP.db then return end
      RLP.db[dbKey].enabled = self:GetChecked() and true or false
      RLP:ApplySettings()
    end)
    local radios = {}
    local function pick(key) return function() RLP.db[dbKey].color = key end end
    radios.WHITE       = MakeRadio("White", 0, 0, pick("WHITE"))
    radios.LIGHT_GRAY  = MakeRadio("Light gray", 0, 0, pick("LIGHT_GRAY"))
    radios.BLACK       = MakeRadio("Black", 0, 0, pick("BLACK"))
    for _, btn in pairs(radios) do SmallLabel(RadioLabel(btn)) end
    -- TEMPORARY SHADOW DEBUG hooks (run after the normal click handlers).
    for _, btn in pairs(radios) do
      btn:HookScript("OnClick", function() RLP:PrintShadowDebug(which) end)
    end
    check:HookScript("OnClick", function() RLP:PrintShadowDebug(which) end)

    -- Widths this block needs: the checkbox row, and the two radio columns.
    local col1W = RADIO_W + math.max(TextW(RadioLabel(radios.WHITE), 40), TextW(RadioLabel(radios.BLACK), 40))
    local col2W = RADIO_W + TextW(RadioLabel(radios.LIGHT_GRAY), 70)
    local needCheck = 6 + 26 + 2 + TextW(cfs, 170) + PAD
    local needRadios = PAD + col1W + COL_GAP + col2W + PAD
    return { box = box, check = check, radios = radios, col1W = col1W,
             need = math.ceil(math.max(needCheck, needRadios)) }
  end
  local rb = ShadowBlock("Rank drop shadow (font)", "rankShadow", "rank")
  local mb = ShadowBlock("Mana cost drop shadow (font)", "manaShadow", "mana")
  local blockW = math.max(BLOCK_MIN_W, rb.need, mb.need)
  local maxBlockW = math.floor((PANEL_W - 2 * 22 - BLOCK_GAP) / 2)
  if blockW > maxBlockW then blockW = maxBlockW end
  local leftX = math.floor((PANEL_W - (blockW * 2 + BLOCK_GAP)) / 2)
  local col2X = PAD + math.ceil(math.max(rb.col1W, mb.col1W)) + COL_GAP
  local y = -236
  for i, blk in ipairs({ rb, mb }) do
    local bx = leftX + (i - 1) * (blockW + BLOCK_GAP)
    blk.box:SetPoint("TOPLEFT", f, "TOPLEFT", bx, y)
    blk.box:SetSize(blockW, BLOCK_H)
    blk.check:SetPoint("TOPLEFT", f, "TOPLEFT", bx + 6, y - 6)
    local r = blk.radios
    for key, pos in pairs({ WHITE = { PAD, -38 }, LIGHT_GRAY = { col2X, -38 },
                            BLACK = { PAD, -60 } }) do
      r[key]:ClearAllPoints()
      r[key]:SetPoint("TOPLEFT", f, "TOPLEFT", bx + pos[1], y + pos[2])
    end
  end
  f.shadowCheck, f.shadowRadios = rb.check, rb.radios
  f.manaShadowCheck, f.manaShadowRadios = mb.check, mb.radios

  -- Position
  -- Two side-by-side headings: Rank positioning over the left half, and
  -- Mana cost positioning over the right half, each with its own controls.
  local HALF = math.floor(PANEL_W / 2)
  Header("Rank\npositioning", -334, 24, HALF - 8)
  f.manaPosHeader = Header("Mana cost\npositioning", -334, HALF + 8, PANEL_W - 24)
  f.positionRadios = {}
  f.positionRadios.LOWERLEFT  = MakeRadio("Lower left", 24, -376, function() RLP.db.rank.position = "LOWERLEFT" end)
  f.positionRadios.LEFTCENTER = MakeRadio("Left center", 112, -376, function() RLP.db.rank.position = "LEFTCENTER" end)

  local function Nudge(dx, dy)
    if RLP.panelSyncing or not RLP.db then return end
    local rank = RLP.db.rank
    rank.offsetX = ClampOffset((rank.offsetX or 0) + dx)
    rank.offsetY = ClampOffset((rank.offsetY or 0) + dy)
    RLP:ApplySettings()
  end

  -- Rank positioning stays in the left half of the window (x 24 to about 190);
  -- mana cost positioning mirrors it in the right half (x 258 on).
  local up = CreateFrame("Button", nil, f, "UIPanelScrollUpButtonTemplate")
  up:SetPoint("TOPLEFT", 62, -412)
  up:SetScript("OnClick", function() Nudge(0, 1) end)
  local left = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
  left:SetSize(22, 18)
  left:SetPoint("RIGHT", up, "LEFT", -10, -20)
  left:SetText("<")
  left:SetScript("OnClick", function() Nudge(-1, 0) end)
  local right = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
  right:SetSize(22, 18)
  right:SetPoint("LEFT", up, "RIGHT", 10, -20)
  right:SetText(">")
  right:SetScript("OnClick", function() Nudge(1, 0) end)
  local down = CreateFrame("Button", nil, f, "UIPanelScrollDownButtonTemplate")
  down:SetPoint("TOP", up, "BOTTOM", 0, -22)
  down:SetScript("OnClick", function() Nudge(0, -1) end)
  local offsetText = f:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
  offsetText:SetPoint("LEFT", right, "RIGHT", 14, 0)
  offsetText:SetText("X 0, Y 0")
  f.offsetText = offsetText

  -- Center the rank positioning controls in their section (the "Rank
  -- positioning" heading's span, x 24 to HALF - 8). Rank controls only;
  -- mana cost positioning is unchanged.
  do
    local x1, x2 = 24, HALF - 8
    -- Lower left / Left center pair, measured like the Outline pair.
    local BTN, LABEL_GAP, PAIR_GAP = 16, 4, 32
    local fa = RadioLabel(f.positionRadios.LOWERLEFT)
    local fb = RadioLabel(f.positionRadios.LEFTCENTER)
    local wa = (fa and fa.GetStringWidth and fa:GetStringWidth()) or 58
    local wb = (fb and fb.GetStringWidth and fb:GetStringWidth()) or 64
    if wa < 1 then wa = 58 end
    if wb < 1 then wb = 64 end
    local firstW = BTN + LABEL_GAP + wa
    local total = firstW + PAIR_GAP + BTN + LABEL_GAP + wb
    local startX = math.floor(x1 + ((x2 - x1) - total) / 2 + 0.5)
    f.positionRadios.LOWERLEFT:ClearAllPoints()
    f.positionRadios.LOWERLEFT:SetPoint("TOPLEFT", f, "TOPLEFT", startX, -376)
    f.positionRadios.LEFTCENTER:ClearAllPoints()
    f.positionRadios.LEFTCENTER:SetPoint("TOPLEFT", f, "TOPLEFT", math.floor(startX + firstW + PAIR_GAP + 0.5), -376)
    -- Nudge arrows plus the X/Y readout, as one group. Width from the left
    -- button to the end of the widest readout ("X -9, Y -9").
    local upW = up:GetWidth(); if not upW or upW < 1 then upW = 18 end
    offsetText:SetText("X -9, Y -9")
    local tw = offsetText:GetStringWidth(); if not tw or tw < 1 then tw = 62 end
    offsetText:SetText("X 0, Y 0")
    local leftPart = 22 + 10           -- "<" button and its gap, left of the up arrow
    local groupW = leftPart + upW + 10 + 22 + 14 + tw
    local groupX = math.floor(x1 + ((x2 - x1) - groupW) / 2 + 0.5)
    up:ClearAllPoints()
    up:SetPoint("TOPLEFT", f, "TOPLEFT", groupX + leftPart, -412)
  end

  -- Mana cost positioning: the same layout as rank positioning, shifted into
  -- the right half by MX pixels. Saved in db.manaPos, with the same 9-pixel cap.
  local MX = HALF + 8 - 24 -- 234: moves x 24 (left half start) to x 258
  f.manaPositionRadios = {}
  f.manaPositionRadios.TOPLEFT   = MakeRadio("Top left", 24 + MX, -376, function() RLP.db.manaPos.position = "TOPLEFT" end)
  f.manaPositionRadios.TOPCENTER = MakeRadio("Top center", 112 + MX, -376, function() RLP.db.manaPos.position = "TOPCENTER" end)
  local function ManaNudge(dx, dy)
    if RLP.panelSyncing or not RLP.db or not RLP.db.manaPos then return end
    local mp = RLP.db.manaPos
    mp.offsetX = ClampOffset((mp.offsetX or 0) + dx)
    mp.offsetY = ClampOffset((mp.offsetY or 0) + dy)
    RLP:ApplySettings()
  end
  local mUp = CreateFrame("Button", nil, f, "UIPanelScrollUpButtonTemplate")
  mUp:SetPoint("TOPLEFT", 62 + MX, -412)
  mUp:SetScript("OnClick", function() ManaNudge(0, 1) end)
  local mLeft = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
  mLeft:SetSize(22, 18)
  mLeft:SetPoint("RIGHT", mUp, "LEFT", -10, -20)
  mLeft:SetText("<")
  mLeft:SetScript("OnClick", function() ManaNudge(-1, 0) end)
  local mRight = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
  mRight:SetSize(22, 18)
  mRight:SetPoint("LEFT", mUp, "RIGHT", 10, -20)
  mRight:SetText(">")
  mRight:SetScript("OnClick", function() ManaNudge(1, 0) end)
  local mDown = CreateFrame("Button", nil, f, "UIPanelScrollDownButtonTemplate")
  mDown:SetPoint("TOP", mUp, "BOTTOM", 0, -22)
  mDown:SetScript("OnClick", function() ManaNudge(0, -1) end)
  local manaOffsetText = f:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
  manaOffsetText:SetPoint("LEFT", mRight, "RIGHT", 14, 0)
  manaOffsetText:SetText("X 0, Y 0")
  f.manaOffsetText = manaOffsetText

  -- Center the mana cost positioning controls in their own section (the
  -- "Mana cost positioning" heading's span, x HALF + 8 to PANEL_W - 24),
  -- the same way as the rank side.
  do
    local x1, x2 = HALF + 8, PANEL_W - 24
    local BTN, LABEL_GAP, PAIR_GAP = 16, 4, 32
    local fa = RadioLabel(f.manaPositionRadios.TOPLEFT)
    local fb = RadioLabel(f.manaPositionRadios.TOPCENTER)
    local wa = (fa and fa.GetStringWidth and fa:GetStringWidth()) or 48
    local wb = (fb and fb.GetStringWidth and fb:GetStringWidth()) or 62
    if wa < 1 then wa = 48 end
    if wb < 1 then wb = 62 end
    local firstW = BTN + LABEL_GAP + wa
    local total = firstW + PAIR_GAP + BTN + LABEL_GAP + wb
    local startX = math.floor(x1 + ((x2 - x1) - total) / 2 + 0.5)
    f.manaPositionRadios.TOPLEFT:ClearAllPoints()
    f.manaPositionRadios.TOPLEFT:SetPoint("TOPLEFT", f, "TOPLEFT", startX, -376)
    f.manaPositionRadios.TOPCENTER:ClearAllPoints()
    f.manaPositionRadios.TOPCENTER:SetPoint("TOPLEFT", f, "TOPLEFT", math.floor(startX + firstW + PAIR_GAP + 0.5), -376)
    local upW = mUp:GetWidth(); if not upW or upW < 1 then upW = 18 end
    manaOffsetText:SetText("X -9, Y -9")
    local tw = manaOffsetText:GetStringWidth(); if not tw or tw < 1 then tw = 62 end
    manaOffsetText:SetText("X 0, Y 0")
    local leftPart = 22 + 10
    local groupW = leftPart + upW + 10 + 22 + 14 + tw
    local groupX = math.floor(x1 + ((x2 - x1) - groupW) / 2 + 0.5)
    mUp:ClearAllPoints()
    mUp:SetPoint("TOPLEFT", f, "TOPLEFT", groupX + leftPart, -412)
  end

  -- Extras
  Header("Extras", -486)
  local mana = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
  mana:SetPoint("TOPLEFT", 18, -506)
  local manaFs = RadioLabel(mana)
  if manaFs then manaFs:SetText("Show mana cost") end
  mana:SetScript("OnClick", function(self)
    if RLP.panelSyncing or not RLP.db then return end
    RLP.db.mana.enabled = self:GetChecked() and true or false
    RLP:RefreshAll()
  end)
  f.manaCheck = mana

  local duration = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
  duration:SetPoint("LEFT", mana, "RIGHT", 160, 0)
  local durFs = RadioLabel(duration)
  if durFs then durFs:SetText("Show duration") end
  duration:SetScript("OnClick", function(self)
    if RLP.panelSyncing or not RLP.db then return end
    RLP.db.duration.enabled = self:GetChecked() and true or false
    RLP:RefreshAll()
  end)
  f.durationCheck = duration

  -- Center the two Extras checkboxes, with their labels, as one row in the window.
  do
    local BOX, LABEL_GAP, PAIR_GAP = 32, 2, 36
    local wa = (manaFs and manaFs.GetStringWidth and manaFs:GetStringWidth()) or 90
    local wb = (durFs and durFs.GetStringWidth and durFs:GetStringWidth()) or 85
    local firstW = BOX + LABEL_GAP + wa
    local total = firstW + PAIR_GAP + BOX + LABEL_GAP + wb
    local startX = math.floor((PANEL_W - total) / 2 + 0.5)
    mana:ClearAllPoints()
    mana:SetPoint("TOPLEFT", f, "TOPLEFT", startX, -506)
    duration:ClearAllPoints()
    duration:SetPoint("TOPLEFT", mana, "TOPLEFT", math.floor(firstW + PAIR_GAP + 0.5), 0)
  end

  local reset = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
  reset:SetSize(140, 22)
  reset:SetPoint("BOTTOM", 0, 22)
  -- Closing flourish above the reset button.
  local endLine = Line(BRONZE[1], BRONZE[2], BRONZE[3], 1)
  endLine:SetHeight(1)
  endLine:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 60, 54)
  endLine:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -60, 54)
  local endShade = Line(DARK_BRONZE[1], DARK_BRONZE[2], DARK_BRONZE[3], 1)
  endShade:SetHeight(1)
  endShade:SetPoint("TOPLEFT", endLine, "BOTTOMLEFT", 0, 0)
  endShade:SetPoint("TOPRIGHT", endLine, "BOTTOMRIGHT", 0, 0)
  local endJewel = Diamond(7, GOLD[1], GOLD[2], GOLD[3])
  endJewel:SetPoint("CENTER", endLine, "CENTER", 0, 0)
  reset:SetText("Reset to defaults")
  reset:SetScript("OnClick", function() RLP:ResetSettings() end)

  -- Save as new default: between the Extras row and the closing flourish.
  -- Stores every current setting as the values Reset to defaults returns to.
  local saveDef = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
  saveDef:SetSize(160, 22)
  saveDef:SetPoint("TOP", f, "TOP", 0, -550)
  saveDef:SetText("Save as new default")
  saveDef:SetScript("OnClick", function() RLP:SaveAsDefaults() end)
  f.saveDefaultButton = saveDef

  -- Listed in the game's AddOns options: a simple page with a button that
  -- opens this window (the window itself is not parented into that list).
  local canvas = CreateFrame("Frame")
  canvas.name = "Rank Label Plus"
  canvas:Hide()
  local title = canvas:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
  title:SetPoint("TOPLEFT", 16, -16)
  title:SetText("Rank Label Plus")
  local openBtn = CreateFrame("Button", nil, canvas, "UIPanelButtonTemplate")
  openBtn:SetSize(180, 24)
  openBtn:SetPoint("TOPLEFT", 16, -48)
  openBtn:SetText("Open settings")
  openBtn:SetScript("OnClick", function() RLP:OpenSettings(true) end)
  canvas.OnCommit = function() end
  canvas.OnDefault = function() RLP:ResetSettings() end
  canvas.OnRefresh = function() end
  if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
    local category = Settings.RegisterCanvasLayoutCategory(canvas, "Rank Label Plus")
    Settings.RegisterAddOnCategory(category)
  elseif InterfaceOptions_AddCategory then
    InterfaceOptions_AddCategory(canvas)
  end

  self:SyncSettingsPanel()
end

function RLP:OpenSettings(forceShow)
  if not self.panel then self:CreateSettingsPanel() end
  local f = self.panel
  if not f then return end
  if forceShow then
    f:Show()
  elseif f:IsShown() then
    f:Hide()
  else
    f:Show()
  end
end

SLASH_RANKLABELPLUS1 = "/irank"
SLASH_RANKLABELPLUS2 = "/ir"
SlashCmdList["RANKLABELPLUS"] = function(msg)
  local rest = msg and msg:match("^%s*[Dd][Ee][Bb][Uu][Gg](.*)$")
  if rest then RLP:Debug(rest) return end
  if msg and msg:match("^%s*[Gg][Ll][Oo][Ww]%s*$") then RLP:PrintGlowDebug() return end -- TRIAL glow
  if msg and msg:match("^%s*[Ff][Aa][Cc][Tt][Oo][Rr][Yy]%s*$") then RLP:ClearSavedDefaults() return end
  if msg and msg:match("^%s*[Oo][Uu][Tt][Ll][Ii][Nn][Ee]%s*$") then RLP:PrintOutlineDebug() return end
  RLP:OpenSettings()
end

---------------------------------------------------------------------------
-- EVENTS
---------------------------------------------------------------------------
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("ACTIONBAR_SLOT_CHANGED")
eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED") -- applies changes held back during combat
eventFrame:RegisterEvent("SPELLS_CHANGED") -- spell and tooltip data finish loading after login
-- TODO later: SPELLS_CHANGED / LEARNED_SPELL_IN_TAB (new ranks), ACTIONBAR_PAGE_CHANGED and
-- UPDATE_BONUS_ACTIONBAR (bar paging, stances, forms)

eventFrame:SetScript("OnEvent", function(_, event, arg1)
  if event == "ADDON_LOADED" and arg1 == ADDON_NAME then
    RankLabelPlusDB = RankLabelPlusDB or {}
    -- Convert a saved color name (and old shadow-color keys) before ApplyDefaults.
    -- ApplyDefaults would otherwise replace a string color with the default RGB table.
    if not RankLabelPlusDB.migratedColorRGB then
      local rank = RankLabelPlusDB.rank
      if type(rank) == "table" then
        if type(rank.color) == "string" then
          local rgb = RLP.rankColors[rank.color] or RLP.rankColors.RED
          rank.color = { r = rgb[1], g = rgb[2], b = rgb[3] }
        elseif type(rank.color) == "table" then
          local c = rank.color
          rank.color = {
            r = tonumber(c.r) or tonumber(c[1]) or 1,
            g = tonumber(c.g) or tonumber(c[2]) or 0,
            b = tonumber(c.b) or tonumber(c[3]) or 0,
          }
        end
        if rank.shadowColor == "MEDIUM_LIGHT_GRAY" then
          rank.shadowColor = "LIGHT_GRAY"
        elseif rank.shadowColor == "MEDIUM_DARK_GRAY" then
          rank.shadowColor = "LIGHT_GRAY" -- Medium gray no longer exists
        end
      end
      RankLabelPlusDB.migratedColorRGB = true
    end
    -- One-time step: the single drop shadow setting became separate rank and
    -- mana cost shadows. Copy the old choice into both so nothing changes.
    if not RankLabelPlusDB.migratedSplitShadow then
      local rank = RankLabelPlusDB.rank
      if type(rank) == "table" and (rank.shadow ~= nil or rank.shadowColor ~= nil) then
        for _, key in ipairs({ "rankShadow", "manaShadow" }) do
          if type(RankLabelPlusDB[key]) ~= "table" then
            RankLabelPlusDB[key] = {
              enabled = (rank.shadow ~= false),
              color = RLP.shadowColors[rank.shadowColor] and rank.shadowColor or "BLACK",
            }
          end
        end
      end
      RankLabelPlusDB.migratedSplitShadow = true
    end
    -- Remember whether a size was already saved, so the old size bump below
    -- only touches existing saves and a fresh install keeps the new defaults.
    local hadSavedSize = type(RankLabelPlusDB.rank) == "table" and RankLabelPlusDB.rank.fontScale ~= nil
    ApplyDefaults(RankLabelPlusDB, RLP.defaults)
    RLP.db = RankLabelPlusDB
    -- One-time step: move a saved size of 12 (old default) or 24 (testing size) to 14.
    -- Uses a new done-flag so saves that already ran the earlier 12-to-24 step still get it.
    if not RankLabelPlusDB.migratedFontScale14 then
      local fs = RankLabelPlusDB.rank.fontScale
      if hadSavedSize and (fs == 12 or fs == 24) then RankLabelPlusDB.rank.fontScale = 14 end
      RankLabelPlusDB.migratedFontScale14 = true
      RankLabelPlusDB.migratedFontScale24 = true
    end
    -- Medium gray shadow was removed: a saved Medium gray becomes Light gray,
    -- and any other unknown shadow color becomes Black.
    for _, key in ipairs({ "rankShadow", "manaShadow" }) do
      local sh = RankLabelPlusDB[key]
      if sh.color == "MEDIUM_GRAY" then
        sh.color = "LIGHT_GRAY"
      elseif not RLP.shadowColors[sh.color] then
        sh.color = "BLACK"
      end
    end
    -- Thick was removed (it drew the same as Normal). A saved Thick, or any
    -- other unknown outline value, becomes Normal.
    if not RLP.thicknessFlags[RankLabelPlusDB.rank.thickness] then
      RankLabelPlusDB.rank.thickness = "NORMAL"
    end
    RankLabelPlusDB.rank.offsetX = ClampOffset(RankLabelPlusDB.rank.offsetX)
    RankLabelPlusDB.rank.offsetY = ClampOffset(RankLabelPlusDB.rank.offsetY)
    RLP:CreateSettingsPanel()
  elseif event == "PLAYER_ENTERING_WORLD" then
    RLP:CreateAllLabels()
    -- At login or /reload the tooltip often has no "Rank N" line yet, so the
    -- first pass finds no ranks and creates no labels. Try again shortly after.
    if C_Timer and C_Timer.After then
      C_Timer.After(1, function() RLP:RefreshAll() end)
      C_Timer.After(3, function() RLP:RefreshAll() end)
    end
  elseif event == "SPELLS_CHANGED" then
    RLP:RefreshAll()
  elseif event == "ACTIONBAR_SLOT_CHANGED" then
    -- Refreshing every known button is cheap (at most a few hundred).
    RLP:RefreshAll()
  elseif event == "PLAYER_REGEN_ENABLED" then
    if RLP.pendingRefresh then RLP:RefreshAll() end
  end
end)
