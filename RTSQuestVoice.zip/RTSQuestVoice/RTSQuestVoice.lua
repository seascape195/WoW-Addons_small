-- RTS Quest Voice (RTSQuestVoice) v1.0.1 by C-scape
-- Plays Warcraft RTS peon lines (or TTS) when you accept and turn in quests.
-- Targets: TBC Anniversary (2.5.5 / 2.5.6) and WoW Forever (1.60.x, Mainline-based UI).

local ADDON_NAME = ...
local PREFIX = "|cffff7f00[QV]|r "

-- Peon voice clips shipped in the game data (FileDataIDs from the wowdev community
-- listfile; presence verified in builds 2.5.6.70006 and 1.60.1.70532 via wago.tools CASC).
local PEON = {
	accept   = 558137, -- sound/creature/peon/peonready1.ogg            ("Ready to work!")
	complete = 558132, -- sound/creature/peon/peonbuildingcomplete1.ogg ("Work complete!")
}

local PHRASE = {
	accept   = "Ready for work",
	complete = "Quest complete",
}

local DEFAULTS = {
	enabled = true,
	mode = "peon",      -- "peon" | "tts" | "both"
	voiceIndex = nil,   -- index into C_VoiceChat.GetTtsVoices(); nil = first/default voice
	pickupSound = true,
	accept = true,      -- quest accept voice (pickup sound + accept line)
	complete = true,    -- quest turn-in voice
	acceptDelay = 1.8,  -- seconds, 1-10
	completeDelay = 1.8,
}

local VALID_MODES = { peon = true, tts = true, both = true }

local db

local function Print(msg)
	if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
		DEFAULT_CHAT_FRAME:AddMessage(PREFIX .. tostring(msg))
	elseif print then
		print("[QV] " .. tostring(msg))
	end
end

local function InitDB()
	if type(RTSQuestVoiceDB) ~= "table" then RTSQuestVoiceDB = {} end
	db = RTSQuestVoiceDB
	for k, v in pairs(DEFAULTS) do
		if db[k] == nil then db[k] = v end
	end
	if not VALID_MODES[db.mode] then db.mode = DEFAULTS.mode end
end

---------------------------------------------------------------------------
-- Sound helpers (every API guarded so nothing errors on either client)
---------------------------------------------------------------------------

local function PlayKit(kitID)
	if not kitID or type(PlaySound) ~= "function" then return false end
	-- Classic accepts a channel string; Mainline/Forever's 2nd arg is a UISoundSubType.
	local ok = pcall(PlaySound, kitID, "Master")
	if not ok then ok = pcall(PlaySound, kitID) end
	return ok
end

local function PlayPickupSFX()
	if not db.pickupSound then return end
	local kit = (type(SOUNDKIT) == "table") and SOUNDKIT.IG_QUEST_LIST_OPEN or nil
	PlayKit(kit or 875) -- 875 = IG_QUEST_LIST_OPEN in both clients' SoundKitConstants
end

local function PlayPeon(which)
	local fdid = PEON[which]
	if not fdid or type(PlaySoundFile) ~= "function" then return false end
	local ok, willPlay = pcall(PlaySoundFile, fdid, "Master")
	return ok and willPlay ~= false
end

local function GetVoices()
	if C_VoiceChat and type(C_VoiceChat.GetTtsVoices) == "function" then
		local ok, voices = pcall(C_VoiceChat.GetTtsVoices)
		if ok and type(voices) == "table" then return voices end
	end
	return {}
end

local function PickVoiceID()
	local voices = GetVoices()
	local v = db.voiceIndex and voices[db.voiceIndex]
	if v and v.voiceID then return v.voiceID end
	-- Fall back to the player's chosen TTS voice in Blizzard settings, then the first voice.
	if C_TTSSettings and type(C_TTSSettings.GetVoiceOptionID) == "function" and Enum and Enum.TtsVoiceType then
		local ok, id = pcall(C_TTSSettings.GetVoiceOptionID, Enum.TtsVoiceType.Standard)
		if ok and type(id) == "number" then return id end
	end
	if voices[1] and voices[1].voiceID then return voices[1].voiceID end
	return nil
end

local function GetRateVolume()
	local rate, volume = 0, 100
	if C_TTSSettings then
		if type(C_TTSSettings.GetSpeechRate) == "function" then
			local ok, r = pcall(C_TTSSettings.GetSpeechRate); if ok and type(r) == "number" then rate = r end
		end
		if type(C_TTSSettings.GetSpeechVolume) == "function" then
			local ok, v = pcall(C_TTSSettings.GetSpeechVolume); if ok and type(v) == "number" and v > 0 then volume = v end
		end
	end
	return rate, volume
end

local function Speak(text)
	if not (C_VoiceChat and type(C_VoiceChat.SpeakText) == "function") then return false end
	local voiceID = PickVoiceID()
	if not voiceID then return false end
	local rate, volume = GetRateVolume()
	local ok
	-- Up to 2.5.5 (and pre-12.0 Mainline): SpeakText(voiceID, text, destination, rate, volume).
	-- 2.5.6+ / 12.0+ / Forever: SpeakText(voiceID, text, rate, volume [, overlap]); the
	-- VoiceTtsDestination enum was removed alongside the argument, so use it as the switch.
	if Enum and Enum.VoiceTtsDestination then
		local dest = Enum.VoiceTtsDestination.LocalPlayback or 1
		ok = pcall(C_VoiceChat.SpeakText, voiceID, text, dest, rate, volume)
	else
		ok = pcall(C_VoiceChat.SpeakText, voiceID, text, rate, volume, true)
	end
	return ok
end

---------------------------------------------------------------------------
-- Announce
---------------------------------------------------------------------------

local function Announce(which)
	local mode = db.mode
	local played = false
	if mode == "peon" or mode == "both" then
		played = PlayPeon(which)
	end
	if mode == "tts" or mode == "both" or (mode == "peon" and not played) then
		-- In peon mode TTS is only a fallback if the clip could not play.
		Speak(PHRASE[which])
	end
end

-- Wait a moment so NPC greetings/acknowledgments finish before the peon speaks.
local MIN_DELAY, MAX_DELAY = 1, 10

local function After(delay, fn)
	delay = tonumber(delay) or 1.8
	if C_Timer and type(C_Timer.After) == "function" then
		C_Timer.After(delay, function() pcall(fn) end)
	else
		pcall(fn)
	end
end

local function OnAccept()
	After(db.acceptDelay, function()
		PlayPickupSFX()
		Announce("accept")
	end)
end

local function OnComplete()
	After(db.completeDelay, function()
		Announce("complete")
	end)
end

---------------------------------------------------------------------------
-- Events (QUEST_TURNED_IN only for completion; QUEST_COMPLETE would double-fire)
---------------------------------------------------------------------------

local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:SetScript("OnEvent", function(self, event, arg1)
	if event == "ADDON_LOADED" then
		if arg1 == ADDON_NAME then
			InitDB()
			pcall(self.RegisterEvent, self, "QUEST_ACCEPTED")
			pcall(self.RegisterEvent, self, "QUEST_TURNED_IN")
			self:UnregisterEvent("ADDON_LOADED")
		end
		return
	end
	if not db or not db.enabled then return end
	if event == "QUEST_ACCEPTED" then
		if db.accept then OnAccept() end
	elseif event == "QUEST_TURNED_IN" then
		if db.complete then OnComplete() end
	end
end)

---------------------------------------------------------------------------
-- Slash command /qv
---------------------------------------------------------------------------

local function Help()
	Print("Commands:")
	Print("/qv - open the settings panel")
	Print("/qv on;  /qv off;  /qv toggle - turn the whole addon on/off")
	Print("/qv mode peon||tts||both - voice mode (now: " .. db.mode .. ")")
	Print("/qv voice - list TTS voices;  /qv voice N - pick voice N")
	Print("/qv accept on||off - quest accept voice (now: " .. (db.accept and "on" or "off") .. ")")
	Print("/qv complete on||off - quest turn-in voice (now: " .. (db.complete and "on" or "off") .. ")")
	Print("/qv accept N;  /qv complete N - set that delay, 1 to 10 seconds (e.g. 3.5)")
	Print("/qv delay - show both delays")
	Print("/qv test accept;  /qv test complete")
	Print("/qv help")
end

local function ListVoices()
	local voices = GetVoices()
	if #voices == 0 then
		Print("No TTS voices available on this client/OS.")
		return
	end
	Print("TTS voices (use /qv voice N):")
	for i, v in ipairs(voices) do
		local mark = (db.voiceIndex == i) and " |cff00ff00<- selected|r" or ""
		Print(("  %d. %s"):format(i, tostring(v.name or v.voiceID)) .. mark)
	end
	if not db.voiceIndex then Print("Currently using your default TTS voice.") end
end

---------------------------------------------------------------------------
-- Settings panel (/qv). Plain CreateFrame widgets so it works on both the
-- TBC Anniversary UI and the Mainline-based Forever UI.
---------------------------------------------------------------------------

local panel

local function Round1(n) return math.floor(n * 10 + 0.5) / 10 end

local function Make(ftype, name, parent, template)
	if template then
		local ok, f = pcall(CreateFrame, ftype, name, parent, template)
		if ok and f then return f, true end
	end
	return CreateFrame(ftype, name, parent), false
end

local function MakeCheck(parent, text, key, y)
	local cb = Make("CheckButton", nil, parent, "UICheckButtonTemplate")
	cb:SetSize(26, 26)
	cb:SetPoint("TOPLEFT", 16, y)
	local label = cb:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	label:SetPoint("LEFT", cb, "RIGHT", 4, 0)
	label:SetText(text)
	cb:SetScript("OnClick", function(self)
		db[key] = self:GetChecked() and true or false
	end)
	cb.key = key
	return cb
end

local function MakeButton(parent, text, w, h)
	local b, templated = Make("Button", nil, parent, "UIPanelButtonTemplate")
	b:SetSize(w, h)
	if templated then
		b:SetText(text)
	else
		local fs = b:CreateFontString(nil, "ARTWORK", "GameFontNormal")
		fs:SetAllPoints(); fs:SetText(text)
		local bg = b:CreateTexture(nil, "BACKGROUND")
		bg:SetAllPoints(); bg:SetColorTexture(0.3, 0.1, 0.1, 0.9)
	end
	return b
end

local function MakeDelay(parent, text, key, y)
	local label = parent:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	label:SetPoint("TOPLEFT", 22, y)
	label:SetText(text)

	local value = parent:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	value:SetPoint("TOPRIGHT", -22, y)

	local s = CreateFrame("Slider", nil, parent)
	s:SetOrientation("HORIZONTAL")
	s:SetSize(220, 16)
	s:SetPoint("TOP", parent, "TOP", 0, y - 20)
	s:SetMinMaxValues(MIN_DELAY, MAX_DELAY)
	s:SetValueStep(0.1)
	if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
	s:EnableMouse(true)
	local track = s:CreateTexture(nil, "BACKGROUND")
	track:SetPoint("LEFT"); track:SetPoint("RIGHT"); track:SetHeight(6)
	track:SetColorTexture(0.25, 0.25, 0.25, 0.9)
	local thumb = s:CreateTexture(nil, "OVERLAY")
	thumb:SetTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
	thumb:SetSize(32, 32)
	s:SetThumbTexture(thumb)

	local function Set(v)
		v = Round1(math.max(MIN_DELAY, math.min(MAX_DELAY, v)))
		db[key] = v
		value:SetText(("%.1f s"):format(v))
	end
	s:SetScript("OnValueChanged", function(self, v) Set(v) end)

	local minus = MakeButton(parent, "-", 24, 22)
	minus:SetPoint("RIGHT", s, "LEFT", -8, 0)
	minus:SetScript("OnClick", function() s:SetValue(Round1(db[key] - 0.1)) end)
	local plus = MakeButton(parent, "+", 24, 22)
	plus:SetPoint("LEFT", s, "RIGHT", 8, 0)
	plus:SetScript("OnClick", function() s:SetValue(Round1(db[key] + 0.1)) end)

	s.key = key
	s.valueText = value
	return s
end

local function BuildPanel()
	local f, templated = Make("Frame", "QuestVoicePanel", UIParent, "BasicFrameTemplateWithInset")
	f:SetSize(340, 215)
	f:SetPoint("CENTER")
	f:SetFrameStrata("DIALOG")
	f:SetClampedToScreen(true)
	f:SetMovable(true)
	f:EnableMouse(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", f.StartMoving)
	f:SetScript("OnDragStop", f.StopMovingOrSizing)
	if not templated then
		local bg = f:CreateTexture(nil, "BACKGROUND")
		bg:SetAllPoints(); bg:SetColorTexture(0, 0, 0, 0.85)
		local close = Make("Button", nil, f, "UIPanelCloseButton")
		close:SetSize(24, 24); close:SetPoint("TOPRIGHT", -2, -2)
		close:SetScript("OnClick", function() f:Hide() end)
	end

	local title = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	title:SetPoint("TOP", 0, -6)
	title:SetText("RTS Quest Voice")

	f.checks = {
		MakeCheck(f, "Quest accept voice", "accept", -32),
		MakeCheck(f, "Quest completion voice", "complete", -116),
	}
	f.sliders = {
		MakeDelay(f, "Accept delay", "acceptDelay", -62),
		MakeDelay(f, "Complete delay", "completeDelay", -146),
	}

	function f:Refresh()
		for _, cb in ipairs(self.checks) do cb:SetChecked(db[cb.key] and true or false) end
		for _, s in ipairs(self.sliders) do
			s:SetValue(db[s.key])
			s.valueText:SetText(("%.1f s"):format(db[s.key]))
		end
	end
	f:SetScript("OnShow", function(self) self:Refresh() end)

	if type(UISpecialFrames) == "table" then table.insert(UISpecialFrames, "QuestVoicePanel") end
	f:Hide()
	return f
end

local function TogglePanel()
	if not panel then panel = BuildPanel() end
	if panel:IsShown() then panel:Hide() else panel:Show() end
end

local function RefreshPanel()
	if panel and panel:IsShown() then panel:Refresh() end
end

SLASH_QUESTVOICE1 = "/qv"
local HandleSlash
SlashCmdList["QUESTVOICE"] = function(msg)
	HandleSlash(msg)
	RefreshPanel()
end
HandleSlash = function(msg)
	if not db then InitDB() end
	msg = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
	local cmd, rest = msg:match("^(%S*)%s*(.-)$")

	if cmd == "" or cmd == "config" or cmd == "options" then
		TogglePanel()
	elseif cmd == "toggle" then
		db.enabled = not db.enabled
		Print(db.enabled and "|cff00ff00enabled|r" or "|cffff4040disabled|r")
	elseif cmd == "on" then
		db.enabled = true; Print("|cff00ff00enabled|r")
	elseif cmd == "off" then
		db.enabled = false; Print("|cffff4040disabled|r")
	elseif cmd == "mode" then
		if VALID_MODES[rest] then
			db.mode = rest; Print("mode set to " .. rest)
		else
			Print("usage: /qv mode peon||tts||both (now: " .. db.mode .. ")")
		end
	elseif cmd == "voice" then
		if rest == "" then
			ListVoices()
		else
			local n = tonumber(rest)
			local voices = GetVoices()
			if n and voices[n] then
				db.voiceIndex = n
				Print("TTS voice set to " .. n .. ". " .. tostring(voices[n].name or voices[n].voiceID))
			else
				Print("invalid voice number; type /qv voice to list voices")
			end
		end
	elseif cmd == "accept" or cmd == "complete" then
		local label = (cmd == "accept") and "quest accept voice" or "quest turn-in voice"
		local key = cmd .. "Delay"
		local n = rest:match("^%d+%.?%d*$") and tonumber(rest) or (rest:match("^%.%d+$") and tonumber(rest))
		if n then
			n = math.floor(n * 10 + 0.5) / 10
			if n < MIN_DELAY or n > MAX_DELAY then
				Print("usage: /qv " .. cmd .. " N, where N is 1 to 10 seconds (now: " .. db[key] .. ")")
			else
				db[key] = n
				Print(label .. " delay set to " .. n .. " seconds")
			end
			return
		end
		if rest == "on" then
			db[cmd] = true
		elseif rest == "off" then
			db[cmd] = false
		elseif rest == "" then
			db[cmd] = not db[cmd]
		else
			Print("usage: /qv " .. cmd .. " on||off||N (N = 1 to 10 seconds)"); return
		end
		Print(label .. (db[cmd] and " |cff00ff00on|r" or " |cffff4040off|r"))
	elseif cmd == "delay" then
		Print("accept delay: " .. db.acceptDelay .. "s;  complete delay: " .. db.completeDelay .. "s")
	elseif cmd == "test" then
		if rest == "accept" then
			Print("test: quest accept"); OnAccept()
		elseif rest == "complete" then
			Print("test: quest complete"); OnComplete()
		else
			Print("usage: /qv test accept||complete")
		end
	else
		Help()
	end
end
